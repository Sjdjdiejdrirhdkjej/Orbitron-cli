import { useChatStore } from "./store/chat-store";

export interface Command {
  name: string;
  description: string;
  aliases: string[];
  execute: () => void;
}

export function getCommands(): Command[] {
  const store = useChatStore.getState();

  return [
    {
      name: "clear",
      description: "Clear chat history",
      aliases: ["/clear", "/c"],
      execute: () => store.clearMessages(),
    },
    {
      name: "models",
      description: "Switch model",
      aliases: ["/models", "/m"],
      execute: () => store.setShowModelPicker(true),
    },
    {
      name: "reset",
      description: "Reset to API key screen",
      aliases: ["/reset", "/r"],
      execute: () => {
        store.clearMessages();
        store.setScreen("apikey");
      },
    },
  ];
}

export function matchCommand(input: string): Command | null {
  const trimmed = input.trim().toLowerCase();
  const commands = getCommands();
  for (const cmd of commands) {
    if (cmd.aliases.some((a) => a.toLowerCase() === trimmed)) {
      return cmd;
    }
  }
  return null;
}

export function isCommandInput(input: string): boolean {
  return input.trim().startsWith("/");
}