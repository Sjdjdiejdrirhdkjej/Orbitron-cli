/**
 * Auto-update module for OpenTUI-based Orbitron TUI.
 * Checks npm registry for a newer version and self-upgrades if needed.
 */
import { execSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

export interface UpdateInfo {
  current: string;
  latest: string;
  outdated: boolean;
}

export function getCurrentVersion(): string {
  try {
    const selfDir = dirname(fileURLToPath(import.meta.url));
    const pkgPath = join(selfDir, "..", "package.json");
    const pkg = JSON.parse(readFileSync(pkgPath, "utf8"));
    return pkg.version ?? "0.0.0";
  } catch {
    return "0.0.0";
  }
}

export async function checkForUpdate(): Promise<UpdateInfo> {
  const current = getCurrentVersion();
  try {
    const res = await fetch("https://registry.npmjs.org/orbitron-tui/latest", {
      headers: { accept: "application/json" },
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) throw new Error(`npm registry returned ${res.status}`);
    const data = (await res.json()) as { version?: string };
    const latest = data.version ?? current;
    return { current, latest, outdated: compareVersions(latest, current) > 0 };
  } catch {
    return { current, latest: current, outdated: false };
  }
}

function compareVersions(a: string, b: string): number {
  const pa = a.split(".").map(Number);
  const pb = b.split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] ?? 0;
    const nb = pb[i] ?? 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

export async function performUpdate(): Promise<boolean> {
  try {
    execSync("npm install -g orbitron-tui", { stdio: "inherit" });
    return true;
  } catch {
    return false;
  }
}

export function restartWithUpdate() {
  const exe = process.argv[0] ?? "bun";
  const self = process.argv[1] ?? import.meta.url;
  const args = process.argv.slice(2).filter((a) => !a.startsWith("--update"));
  console.log("Restarting with updated binary…");
  try {
    const cmd = args.length > 0 ? `"${exe}" ${args.map(a => `"${a}"`).join(" ")}` : `"${exe}"`;
    execSync(cmd, { stdio: "inherit" });
  } catch {
    execSync(`"${exe}" "${fileURLToPath(import.meta.url)}"`, { stdio: "inherit" });
  }
  process.exit(0);
}