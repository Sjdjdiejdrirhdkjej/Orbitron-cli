import React, { useState, useCallback, useEffect } from "react";
import { useKeyboard } from "@opentui/react";
import { TextAttributes } from "@opentui/core";
import { useChatStore } from "../store/chat-store";
import { getTheme } from "../theme/index";
import { listModels, streamChat } from "../api/chat";
import { matchCommand, isCommandInput } from "../commands";

interface Props {}

export function ChatScreen(_props: Props) {
  const theme = getTheme("dark");
  const config = useChatStore((s) => s.config);
  const messages = useChatStore((s) => s.messages);
  const addMessage = useChatStore((s) => s.addMessage);
  const isStreaming = useChatStore((s) => s.isStreaming);
  const setIsStreaming = useChatStore((s) => s.setIsStreaming);
  const streamingContent = useChatStore((s) => s.streamingContent);
  const setStreamingContent = useChatStore((s) => s.setStreamingContent);
  const lastError = useChatStore((s) => s.lastError);
  const setLastError = useChatStore((s) => s.setLastError);
  const setStatus = useChatStore((s) => s.setStatus);
  const setScreen = useChatStore((s) => s.setScreen);

  const [input, setInput] = useState("");
  const [modelCount, setModelCount] = useState<number>(0);
  const [apiKeyMissing, setApiKeyMissing] = useState(false);

  useEffect(() => {
    if (!config.apiKey.trim()) {
      setApiKeyMissing(true);
      setScreen("apikey");
      setStatus("API key required");
      return;
    }

    setApiKeyMissing(false);
    setStatus("Discovering models...");
    listModels(config.baseUrl)
      .then((m) => setModelCount(m.length))
      .catch((err: Error) => setLastError(err.message))
      .finally(() => setStatus("Ready"));
  }, [config.apiKey, config.baseUrl, setLastError, setScreen, setStatus]);

  const handleSubmit = useCallback(async () => {
    const text = input.trim();
    if (!text || isStreaming || apiKeyMissing) return;

    if (isCommandInput(text)) {
      const cmd = matchCommand(text);
      if (cmd) {
        setInput("");
        cmd.execute();
        return;
      }
      setInput("");
      addMessage({ role: "user", content: text });
      addMessage({ role: "assistant", content: `Unknown command. Available: /clear, /models, /reset` });
      return;
    }

    setInput("");
    addMessage({ role: "user", content: text });
    setIsStreaming(true);
    setStreamingContent("");
    setStatus("Streaming...");

    try {
      let full = "";
      const promptMessages = [
        ...messages,
        { role: "user" as const, content: text },
      ].filter((m) => m.role !== "system");

      for await (const chunk of streamChat({
        baseUrl: config.baseUrl,
        apiKey: config.apiKey,
        model: config.model,
        messages: promptMessages.map((m) => ({ role: m.role as string, content: m.content })),
        temperature: config.temperature,
        maxTokens: config.maxTokens,
      })) {
        full += chunk;
        setStreamingContent(full);
      }

      addMessage({ role: "assistant", content: full });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setLastError(msg);
      addMessage({ role: "assistant", content: `[Error] ${msg}` });
    } finally {
      setIsStreaming(false);
      setStreamingContent("");
      setStatus("Ready");
    }
  }, [
    input,
    isStreaming,
    apiKeyMissing,
    config,
    messages,
    addMessage,
    setIsStreaming,
    setStreamingContent,
    setLastError,
    setStatus,
  ]);

  useKeyboard(
    useCallback(
      (key: { name: string; ctrl: boolean; meta: boolean; shift: boolean; sequence: string; preventDefault?: () => void }) => {
        if (
          (key.name === "return" || key.name === "enter") &&
          !key.ctrl && !key.meta && !key.shift &&
          !isStreaming && input.trim() && !apiKeyMissing
        ) {
          key.preventDefault?.();
          void handleSubmit();
          return;
        }
        if (key.ctrl && key.name === "c") {
          key.preventDefault?.();
          if (isStreaming) {
            setIsStreaming(false);
            setStreamingContent("");
          } else {
            process.exit(0);
          }
          return;
        }
        if (key.name === "backspace") {
          setInput((prev) => prev.slice(0, -1));
          return;
        }
        if (key.name === "escape") {
          setScreen("apikey");
          return;
        }
        const seq = key.sequence || key.name;
        if (seq && seq.length === 1 && !key.ctrl && !key.meta) {
          setInput((prev) => prev + seq);
        }
      },
      [input, isStreaming, apiKeyMissing, handleSubmit, setIsStreaming, setScreen, setStreamingContent]
    )
  );

  return (
    <box
      style={{
        width: "100%",
        height: "100%",
        backgroundColor: theme.surface,
        flexDirection: "column",
      }}
    >
      <box
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          padding: 1,
          borderStyle: "single",
          borderColor: theme.border,
          border: ["bottom"],
          flexShrink: 0,
        }}
      >
        <text style={{ fg: theme.primary, attributes: TextAttributes.BOLD }}>
          OpenTUI
        </text>
        <text style={{ fg: theme.muted }}>
          {config.model}
        </text>
        <text style={{ fg: theme.muted }}>
          {modelCount > 0 ? `${modelCount}M` : "…"}
        </text>
      </box>

      <box
        style={{
          flexGrow: 1,
          flexDirection: "column",
          padding: 1,
          overflow: "hidden",
        }}
      >
        {apiKeyMissing ? (
          <text style={{ fg: theme.error }}>
            Paste an API key in the OpenTUI screen to start chatting.
          </text>
        ) : messages.length === 0 ? (
          <text style={{ fg: theme.muted }}>
            Ask anything…
          </text>
        ) : null}
        {messages.map((msg) => (
          <box key={msg.id} style={{ marginBottom: 0 }}>
            <text style={{ fg: theme.muted }}>
              {msg.role === "user" ? "›" : msg.role === "assistant" ? "·" : ""}{" "}
            </text>
            <text style={{ fg: theme.foreground, wrapMode: "word" }}>
              {msg.content}
            </text>
          </box>
        ))}
        {isStreaming && streamingContent && (
          <box>
            <text style={{ fg: theme.muted }}>· </text>
            <text style={{ fg: theme.primary }}>{streamingContent}</text>
          </box>
        )}
      </box>

      {lastError && (
        <box style={{ padding: 1, flexShrink: 0 }}>
          <text style={{ fg: theme.error }}>✗ {lastError}</text>
        </box>
      )}

      <box
        style={{
          flexDirection: "row",
          padding: 1,
          borderStyle: "single",
          borderColor: theme.border,
          border: ["top"],
          flexShrink: 0,
          alignItems: "center",
        }}
      >
        <text style={{ fg: theme.primary }}>›</text>
        <text style={{ fg: theme.foreground, flexGrow: 1, marginLeft: 1 }}>
          {input || " "}
        </text>
        {isStreaming ? (
          <text style={{ fg: theme.primary }}>▌ Ctrl+C</text>
        ) : (
          <text style={{ fg: theme.muted }}>
            /clear · /models · /reset
          </text>
        )}
      </box>
    </box>
  );
}