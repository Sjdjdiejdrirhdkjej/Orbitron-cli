import React, { useState, useCallback } from "react";
import { useKeyboard } from "@opentui/react";
import { TextAttributes } from "@opentui/core";
import { useChatStore } from "../store/chat-store";
import { getTheme } from "../theme/index";

interface Props {}

export function ApiKeyScreen(_props: Props) {
  const theme = getTheme("dark");
  const [input, setInput] = useState("");
  const [error, setError] = useState("");
  const setConfig = useChatStore((s) => s.setConfig);
  const setScreen = useChatStore((s) => s.setScreen);

  const handleSubmit = useCallback(() => {
    const key = input.trim();
    if (!key) {
      setError("Please paste your API key");
      return;
    }
    setConfig({ apiKey: key });
    setScreen("chat");
  }, [input, setConfig, setScreen]);

  useKeyboard(
    useCallback(
      (key: { name?: string; sequence?: string; ctrl?: boolean; meta?: boolean; shift?: boolean }) => {
        if (key.name === "return" || key.name === "enter") {
          handleSubmit();
          return;
        }
        if (key.name === "backspace") {
          setInput((prev) => prev.slice(0, -1));
          return;
        }
        if (key.ctrl && key.name === "c") {
          process.exit(0);
          return;
        }
        const seq = key.sequence || key.name;
        if (seq && seq.length === 1 && !key.ctrl && !key.meta) {
          setInput((prev) => prev + seq);
        }
      },
      [handleSubmit]
    )
  );

  const masked = input.length > 0 ? "*".repeat(Math.min(input.length, 24)) : "";

  return (
    <box
      style={{
        width: "100%",
        height: "100%",
        backgroundColor: theme.surface,
        flexDirection: "column",
        padding: 1,
      }}
    >
      <box
        style={{
          flexDirection: "column",
          alignItems: "center",
          marginBottom: 1,
          flexShrink: 0,
        }}
      >
        <text style={{ fg: theme.primary, attributes: TextAttributes.BOLD }}>
          OpenTUI
        </text>
      </box>

      <box
        style={{
          flexGrow: 1,
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: 0,
        }}
      >
        <text style={{ fg: theme.foreground }}>
          API Key
        </text>
        <box
          style={{
            width: "100%",
            maxWidth: 320,
            flexDirection: "column",
            borderStyle: "single",
            borderColor: error ? theme.error : theme.border,
            padding: 1,
          }}
        >
          <text style={{ fg: theme.muted }}>▸ {masked || "(paste your key)"}</text>
        </box>
        {error && (
          <text style={{ fg: theme.error }}>{error}</text>
        )}
        <text style={{ fg: theme.muted }}>
          Enter to continue · Ctrl+C exit
        </text>
      </box>

      <box style={{ flexShrink: 0 }}>
        <text style={{ fg: theme.muted }}>
          saved locally · orbitron.config.json
        </text>
      </box>
    </box>
  );
}