import React, { useCallback, useEffect, useState } from "react";
import { useKeyboard } from "@opentui/react";
import { TextAttributes } from "@opentui/core";
import { useChatStore } from "../store/chat-store";
import { getTheme } from "../theme/index";
import { listModels } from "../api/chat";

interface Props {}

export function ModelPicker(_props: Props) {
  const theme = getTheme("dark");
  const showModelPicker = useChatStore((s) => s.showModelPicker);
  const setShowModelPicker = useChatStore((s) => s.setShowModelPicker);
  const availableModels = useChatStore((s) => s.availableModels);
  const setAvailableModels = useChatStore((s) => s.setAvailableModels);
  const config = useChatStore((s) => s.config);
  const setConfig = useChatStore((s) => s.setConfig);

  const [selectedIdx, setSelectedIdx] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!showModelPicker) return;
    if (availableModels.length > 0) return;

    setLoading(true);
    setError("");
    listModels(config.baseUrl)
      .then((m) => {
        setAvailableModels(m);
        if (m.length > 0) {
          const currentIdx = m.findIndex((model) => model.id === config.model);
          setSelectedIdx(currentIdx >= 0 ? currentIdx : 0);
        }
      })
      .catch((err: Error) => setError(err.message))
      .finally(() => setLoading(false));
  }, [showModelPicker, availableModels.length, config.baseUrl, config.model, setAvailableModels]);

  const handleSelect = useCallback(
    (modelId: string) => {
      setConfig({ model: modelId });
      setShowModelPicker(false);
    },
    [setConfig, setShowModelPicker]
  );

  const handleClose = useCallback(() => {
    setShowModelPicker(false);
  }, [setShowModelPicker]);

  useKeyboard(
    useCallback(
      (key: { name: string; ctrl: boolean; meta: boolean; shift: boolean; sequence: string; preventDefault?: () => void }) => {
        if (!showModelPicker) return;

        if (key.name === "escape" || (key.ctrl && key.name === "c")) {
          key.preventDefault?.();
          handleClose();
          return;
        }
        if (key.name === "up" || key.name === "k") {
          key.preventDefault?.();
          setSelectedIdx((prev) => (prev - 1 + availableModels.length) % availableModels.length);
          return;
        }
        if (key.name === "down" || key.name === "j") {
          key.preventDefault?.();
          setSelectedIdx((prev) => (prev + 1) % availableModels.length);
          return;
        }
        if (key.name === "return" || key.name === "enter") {
          key.preventDefault?.();
          if (availableModels[selectedIdx]) {
            handleSelect(availableModels[selectedIdx].id);
          }
          return;
        }
        if (key.name === "backspace" || key.name === "delete") {
          key.preventDefault?.();
          handleClose();
          return;
        }
      },
      [showModelPicker, availableModels.length, selectedIdx, handleSelect, handleClose]
    )
  );

  if (!showModelPicker) return null;

  const modalWidth = Math.min(48, Math.floor((availableModels.length || 1) * 1));
  const visibleModels = availableModels.slice(0, 12);
  const currentIdx = availableModels.findIndex((m) => m.id === config.model);

  return (
    <box
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        backgroundColor: "rgba(0,0,0,0.6)",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <box
        style={{
          width: modalWidth,
          flexDirection: "column",
          borderStyle: "double",
          borderColor: theme.primary,
          backgroundColor: theme.surface,
        }}
      >
        <box
          style={{
            flexDirection: "row",
            padding: 1,
            borderStyle: "single",
            borderColor: theme.border,
            border: ["bottom"],
          }}
        >
          <text style={{ fg: theme.primary, attributes: TextAttributes.BOLD }}>
            ◈ Models
          </text>
          <text style={{ fg: theme.muted, marginLeft: 2 }}>
            {loading ? "loading…" : `${availableModels.length} available`}
          </text>
        </box>

        {error && (
          <box style={{ padding: 1 }}>
            <text style={{ fg: theme.error }}>✗ {error}</text>
          </box>
        )}

        <box
          style={{
            flexDirection: "column",
            maxHeight: 12,
            padding: 0,
          }}
        >
          {loading ? (
            <box style={{ padding: 1 }}>
              <text style={{ fg: theme.muted }}>Fetching models…</text>
            </box>
          ) : availableModels.length === 0 ? (
            <box style={{ padding: 1 }}>
              <text style={{ fg: theme.muted }}>No models found</text>
            </box>
          ) : (
            visibleModels.map((model, idx) => (
              <box
                key={model.id}
                style={{
                  padding: 1,
                  borderStyle: "single",
                  borderColor: idx === selectedIdx ? theme.primary : "transparent",
                  border: idx === selectedIdx ? ["left"] : [],
                }}
              >
                <text style={{ fg: idx === selectedIdx ? theme.primary : theme.foreground }}>
                  {idx === selectedIdx ? "▸" : " "}
                </text>
                <text
                  style={{
                    fg: model.id === config.model ? theme.success : idx === selectedIdx ? theme.primary : theme.foreground,
                    marginLeft: 1,
                  }}
                >
                  {model.name || model.id}
                </text>
                {model.provider && (
                  <text style={{ fg: theme.muted, marginLeft: 2 }}>
                    · {model.provider}
                  </text>
                )}
                {model.id === config.model && (
                  <text style={{ fg: theme.success, marginLeft: 2 }}>✓</text>
                )}
              </box>
            ))
          )}
        </box>

        <box
          style={{
            padding: 1,
            borderStyle: "single",
            borderColor: theme.border,
            border: ["top"],
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        >
          <text style={{ fg: theme.muted }}>↑↓ navigate · ↵ select · Esc close</text>
          {currentIdx >= 0 && (
            <text style={{ fg: theme.muted }}>current: {config.model}</text>
          )}
        </box>
      </box>
    </box>
  );
}