const BASE = "https://orbitron--pastelsjuice8t.replit.app";

export function resolveApiUrl(baseUrl: string, pathname: string): string {
  const base = baseUrl.replace(/\/$/, "");
  return new URL(pathname, `${base}/`).toString();
}

export interface ModelInfo {
  id: string;
  name?: string;
  provider?: string;
  context_window?: number;
  pricing?: {
    input_per_million?: number;
    output_per_million?: number;
  };
}

export async function listModels(baseUrl: string): Promise<ModelInfo[]> {
  const res = await fetch(resolveApiUrl(baseUrl, "/api/models"), {
    headers: { accept: "application/json" },
  });
  if (!res.ok) throw new Error(`Model fetch failed (${res.status})`);
  const text = await res.text();
  try {
    const data = JSON.parse(text);
    if (Array.isArray(data?.data)) return data.data;
    if (Array.isArray(data?.models)) return data.models;
    if (Array.isArray(data?.items)) return data.items;
    return [];
  } catch {
    return [];
  }
}

export async function* streamChat({
  baseUrl,
  apiKey,
  model,
  messages,
  temperature = 0.2,
  maxTokens = 2048,
}: {
  baseUrl: string;
  apiKey: string;
  model: string;
  messages: { role: string; content: string }[];
  temperature?: number;
  maxTokens?: number;
}) {
  const res = await fetch(resolveApiUrl(baseUrl, "/api/chat"), {
    method: "POST",
    headers: {
      "content-type": "application/json",
      accept: "application/json",
      ...(apiKey ? { authorization: `Bearer ${apiKey}` } : {}),
    },
    body: JSON.stringify({
      model,
      messages,
      temperature,
      max_tokens: maxTokens,
      stream: true,
    }),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Chat failed (${res.status}): ${text.slice(0, 300)}`);
  }

  if (!res.body) throw new Error("Response body is not available");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split("\n");
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const data = line.slice(6).trim();
        if (data === "[DONE]") return;
        try {
          const parsed = JSON.parse(data);
          const text =
            parsed.choices?.[0]?.delta?.content ??
            parsed.choices?.[0]?.text ??
            parsed.text ??
            parsed.output ??
            "";
          if (text) yield text;
        } catch {
          // skip
        }
      }
    }
  } finally {
    reader.cancel();
  }
}