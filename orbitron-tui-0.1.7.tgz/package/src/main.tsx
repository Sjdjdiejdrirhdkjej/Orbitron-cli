import { createRoot } from "@opentui/react";
import { createCliRenderer } from "@opentui/core";
import React from "react";
import { App } from "./App";
import { checkForUpdate, performUpdate, restartWithUpdate, getCurrentVersion } from "./update";

async function main() {
  // Check for updates unless --no-update flag is passed
  const skipUpdate = process.argv.includes("--no-update");
  if (!skipUpdate) {
    try {
      const info = await checkForUpdate();
      if (info.outdated) {
        console.log(`Updating orbitron-tui ${info.current} → ${info.latest}…`);
        const ok = await performUpdate();
        if (ok) {
          console.log("Update installed. Restarting…");
          restartWithUpdate();
          return;
        } else {
          console.log("Update failed, continuing with current version.");
        }
      }
    } catch {
      // Network error — skip update check silently
    }
  }

  const renderer = await createCliRenderer({
    backgroundColor: "transparent",
    exitOnCtrlC: false,
  });

  createRoot(renderer).render(<App />);
}

main().catch((err) => {
  console.error("Fatal:", err);
  process.exit(1);
});