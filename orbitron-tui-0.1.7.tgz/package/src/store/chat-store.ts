import { create } from "zustand";
import { immer } from "zustand/middleware/immer";

export interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: number;
  thinking?: string;
}

export interface ModelInfo {
  id: string;
  name?: string;
  provider?: string;
}

export interface Config {
  baseUrl: string;
  apiKey: string;
  model: string;
  temperature: number;
  maxTokens: number;
}

export type AppScreen = "apikey" | "chat";

interface ChatState {
  // Config
  config: Config;
  setConfig: (partial: Partial<Config>) => void;

  // Screen
  screen: AppScreen;
  setScreen: (screen: AppScreen) => void;

  // Messages
  messages: Message[];
  addMessage: (msg: Omit<Message, "id" | "timestamp">) => string;
  updateMessage: (id: string, partial: Partial<Message>) => void;
  clearMessages: () => void;

  // Streaming
  isStreaming: boolean;
  setIsStreaming: (v: boolean) => void;
  streamingContent: string;
  setStreamingContent: (v: string) => void;
  appendStreamingContent: (chunk: string) => void;

  // Error
  lastError: string;
  setLastError: (msg: string) => void;

  // Status
  status: string;
  setStatus: (msg: string) => void;

  // Model picker
  showModelPicker: boolean;
  setShowModelPicker: (v: boolean) => void;
  availableModels: ModelInfo[];
  setAvailableModels: (models: ModelInfo[]) => void;
}

const DEFAULT_CONFIG: Config = {
  baseUrl: "https://orbitron--pastelsjuice8t.replit.app",
  apiKey: "",
  model: "gpt-4.1-mini",
  temperature: 0.2,
  maxTokens: 2048,
};

export const useChatStore = create<ChatState>()(
  immer((set) => ({
    config: { ...DEFAULT_CONFIG },
    setConfig: (partial) =>
      set((s) => {
        Object.assign(s.config, partial);
      }),

    screen: "apikey",
    setScreen: (screen) =>
      set((s) => {
        s.screen = screen;
      }),

    messages: [],
    addMessage: (msg) => {
      const id = crypto.randomUUID();
      set((s) => {
        s.messages.push({
          ...msg,
          id,
          timestamp: Date.now(),
        });
      });
      return id;
    },
    updateMessage: (id, partial) =>
      set((s) => {
        const idx = s.messages.findIndex((m) => m.id === id);
        if (idx !== -1) Object.assign(s.messages[idx], partial);
      }),
    clearMessages: () =>
      set((s) => {
        s.messages = [];
      }),

    isStreaming: false,
    setIsStreaming: (v) =>
      set((s) => {
        s.isStreaming = v;
      }),
    streamingContent: "",
    setStreamingContent: (v) =>
      set((s) => {
        s.streamingContent = v;
      }),
    appendStreamingContent: (chunk) =>
      set((s) => {
        s.streamingContent += chunk;
      }),

    lastError: "",
    setLastError: (msg) =>
      set((s) => {
        s.lastError = msg;
      }),

    status: "Ready",
    setStatus: (msg) =>
      set((s) => {
        s.status = msg;
      }),

    showModelPicker: false,
    setShowModelPicker: (v) =>
      set((s) => {
        s.showModelPicker = v;
      }),
    availableModels: [],
    setAvailableModels: (models) =>
      set((s) => {
        s.availableModels = models;
      }),
  }))
);