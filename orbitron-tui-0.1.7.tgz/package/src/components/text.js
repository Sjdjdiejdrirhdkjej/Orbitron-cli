export function truncate(text, width) {
  const str = String(text ?? '');
  if (width <= 0) return '';
  return str.length > width ? str.slice(0, Math.max(0, width - 1)) + '…' : str;
}

export function repeat(ch, count) {
  return count > 0 ? ch.repeat(count) : '';
}

export function pad(text, width) {
  const clean = truncate(text, width);
  return clean + repeat(' ', Math.max(0, width - clean.length));
}

export function wrapText(text, width) {
  const plain = String(text ?? '');
  if (width <= 1) return [plain];
  return plain.split(/\r?\n/).flatMap((line) => {
    if (!line.length) return [''];
    const chunks = [];
    let rest = line;
    while (rest.length > width) {
      chunks.push(rest.slice(0, width));
      rest = rest.slice(width);
    }
    if (rest) chunks.push(rest);
    return chunks;
  });
}
