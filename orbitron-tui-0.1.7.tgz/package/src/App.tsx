import React from "react";
import { useChatStore } from "./store/chat-store";
import { ApiKeyScreen } from "./screens/api-key-screen";
import { ChatScreen } from "./screens/chat-screen";

export function App() {
  const screen = useChatStore((s) => s.screen);

  return (
    <box
      style={{
        width: "100%",
        height: "100%",
        backgroundColor: "transparent",
        flexDirection: "column",
      }}
    >
      {screen === "apikey" && <ApiKeyScreen />}
      {screen === "chat" && <ChatScreen />}
    </box>
  );
}