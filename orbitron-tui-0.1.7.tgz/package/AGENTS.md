# Project memory

- **Stack**: Bun + OpenTUI (@opentui/react + @opentui/core) + React 19 + TypeScript
- **Entry point**: `src/main.tsx` — run via `bun run src/main.tsx --cwd .`
- **Bin**: `bin/orbitron` (bun ESM script — self-locates via `import.meta.url`, works from any install path)
- **Backend**: `https://orbitron--pastelsjuice8t.replit.app` (via `/api/chat` and `/api/models`)
- **State**: zustand store at `src/store/chat-store.ts`
- **Theme**: dark theme in `src/theme/index.ts`

## Architecture

- `src/main.tsx` — creates OpenTUI renderer + `createRoot(renderer).render(<App />)`
- `src/App.tsx` — routes between `ApiKeyScreen` and `ChatScreen` based on store `screen` state
- `src/store/chat-store.ts` — zustand + immer store for all app state
- `src/screens/api-key-screen.tsx` — full-screen API key prompt with `useKeyboard` for raw input
- `src/screens/chat-screen.tsx` — chat UI with message list + keyboard input + streaming
- `src/api/chat.ts` — `listModels()` and `streamChat()` async generator for the backend
- `src/commands.ts` — slash command registry (`/clear`, `/models`, `/reset`)
- `src/update.ts` — auto-update via npm registry check + `npm install -g` + hard restart

## Key patterns

- `useKeyboard(handler)` from `@opentui/react` gives raw keystrokes including `key.name`, `key.ctrl`, `key.sequence`, `key.preventDefault()`
- OpenTUI JSX components: `<box>`, `<text>`, `<span>` — no `className`, style is a plain object
- `TextAttributes.BOLD` from `@opentui/core` for bold text
- Stream with `for await (const chunk of streamChat(...))` — generator yields partial tokens
- State updates via `immer` middleware — mutate directly, no spread needed
- Commands: `isCommandInput()` checks for `/`, `matchCommand()` returns the Command or null

## Notes

- The original Node.js kleur-based TUI (src/cli.js) is still present but superseded by src/main.tsx
- API key is stored in config via zustand store, not persisted to disk yet (TODO)
- Backend already points to `https://orbitron--pastelsjuice8t.replit.app/` — no Codebuff auth/backend dependencies found