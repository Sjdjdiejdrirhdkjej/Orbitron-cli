import fs from 'node:fs';
import kleur from 'kleur';
import { estimateCost, estimateTokens, pad, repeat, truncate, wrapText } from '../render.js';
import { readPreview, formatFileSize, formatFileMtime } from '../files.js';
import { cycleMode, formatModeName, MODE_NAMES } from '../state.js';

const ORBITRON_LOGO = [
  '  ██████  ██████  ██████  ██ ████████ ██████   ██████  ███    ██',
  ' ██    ██ ██   ██ ██   ██ ██    ██    ██   ██ ██    ██ ████   ██',
  ' ██    ██ ██████  ██████  ██    ██    ██████  ██    ██ ██ ██  ██',
  ' ██    ██ ██   ██ ██   ██ ██    ██    ██   ██ ██    ██ ██  ██ ██',
  '  ██████  ██   ██ ██████  ██    ██    ██   ██  ██████  ██   ████',
];

function renderModeStrip(state, width) {
  const current = String(state.mode ?? 'default').trim().toLowerCase();
  const parts = MODE_NAMES.map((mode) => {
    const label = formatModeName(mode);
    return mode === current ? kleur.bold().cyan(label) : kleur.gray(label);
  });
  return truncate(`${kleur.gray('Mode: ')}${parts.join(kleur.gray(' | '))}${kleur.gray('   /mode   Shift+Tab')}`, width);
}

function renderCompactBanner(state, width) {
  const lines = [];
  lines.push(truncate(kleur.cyan().bold('Orbitron TUI'), width));
  lines.push(truncate(kleur.gray('Terminal-first chat with context and streaming.'), width));
  lines.push(truncate(kleur.gray(`Model ${state.config.model} · ${state.config.apiKey ? 'authenticated' : 'API key required'}`), width));
  lines.push(renderModeStrip(state, width));
  return lines;
}

/**
 * Detect language from file extension.
 */
function langFromExt(ext) {
  const map = {
    js: 'js', ts: 'js', jsx: 'js', tsx: 'js', mjs: 'js', cjs: 'js',
    py: 'py', pyw: 'py',
    json: 'json', jsonc: 'json',
    html: 'html', htm: 'html',
    css: 'css', scss: 'css', less: 'css',
    sh: 'sh', bash: 'sh', zsh: 'sh',
    md: 'md', markdown: 'md',
    yaml: 'yaml', yml: 'yaml',
    toml: 'toml',
    xml: 'xml',
    rs: 'rust', go: 'go', java: 'java', kt: 'kotlin', swift: 'swift',
    c: 'c', cpp: 'cpp', h: 'c', hpp: 'cpp',
    cs: 'csharp', rb: 'ruby', php: 'php',
    txt: 'text', text: 'text',
  };
  return map[ext?.toLowerCase()] ?? 'text';
}

/**
 * Read file synchronously, return array of lines or null on error.
 */
export function readFilePreviewSync(absPath, maxLines = 24) {
  try {
    const raw = fs.readFileSync(absPath, 'utf8');
    const lines = raw.split('\n');
    return { lines, total: lines.length };
  } catch {
    return null;
  }
}

/**
 * Colourise a single line of code based on detected language (file extension).
 * Zero-dependency — uses only kleur primitives.
 */
function colourLine(line, lang) {
  if (lang === 'py') {
    return line
      .replace(/"[^"]*"/g, (m) => kleur.green(m))
      .replace(/'[^']*'/g, (m) => kleur.green(m))
      .replace(/#.*/, (m) => kleur.gray(m))
      .replace(/\b(def|class|return|if|elif|else|for|while|import|from|as|try|except|finally|with|raise|pass|break|continue|and|or|not|in|is|lambda|yield|global|nonlocal|True|False|None|async|await)\b/g, (m) => kleur.cyan(m));
  }
  if (lang === 'js' || lang === 'ts') {
    return line
      .replace(/"[^"]*"/g, (m) => kleur.green(m))
      .replace(/'[^']*'/g, (m) => kleur.green(m))
      .replace(/`[^`]*`/g, (m) => kleur.green(m))
      .replace(/\/\/.*/, (m) => kleur.gray(m))
      .replace(/\/\*[\s\S]*?\*\//g, (m) => kleur.gray(m))
      .replace(/\b(const|let|var|function|return|if|else|for|while|class|import|export|from|async|await|try|catch|throw|new|this|typeof|instanceof|switch|case|default|break|continue|void|delete|in|of|null|undefined|true|false|interface|type|enum|implements|extends|static|readonly|abstract|private|public|protected)\b/g, (m) => kleur.cyan(m));
  }
  if (lang === 'json') {
    return line
      .replace(/"([^"]+)":?/g, (_, k) => kleur.yellow(`"${k}"`) + (line.includes(':') ? kleur.gray(':') : ''))
      .replace(/\b(true|false|null)\b/g, (m) => kleur.magenta(m))
      .replace(/\b\d+(\.\d+)?([eE][+-]?\d+)?\b/g, (m) => kleur.magenta(m));
  }
  if (lang === 'html') {
    return line
      .replace(/<\/?[\w\-]+/g, (m) => kleur.cyan(m))
      .replace(/>[^<]*/g, (m) => kleur.gray(m))
      .replace(/\s([\w\-]+)=/g, (_, a) => ` ${kleur.yellow(a)}=`)
      .replace(/"[^"]*"/g, (m) => kleur.green(m))
      .replace(/'[^']*'/g, (m) => kleur.green(m));
  }
  if (lang === 'css') {
    return line
      .replace(/[.#][\w\-]+/g, (m) => kleur.cyan(m))
      .replace(/[\w\-]+:(?!\s)/g, (m) => kleur.yellow(m))
      .replace(/"[^"]*"/g, (m) => kleur.green(m))
      .replace(/'[^']*'/g, (m) => kleur.green(m))
      .replace(/\/\*[\s\S]*?\*\//g, (m) => kleur.gray(m));
  }
  if (lang === 'sh') {
    return line
      .replace(/#.*/, (m) => kleur.gray(m))
      .replace(/\b(if|then|else|elif|fi|for|while|do|done|case|esac|in|function|return|exit|export|source|alias|echo|read|local|readonly|declare|shift|set|unset|test)\b/g, (m) => kleur.cyan(m))
      .replace(/"[^"]*"/g, (m) => kleur.green(m))
      .replace(/'[^']*'/g, (m) => kleur.green(m));
  }
  if (lang === 'md') {
    return line
      .replace(/#{1,6}\s.*/, (m) => kleur.cyan().bold(m))
      .replace(/```[\w]*\s*/, (m) => kleur.cyan(m))
      .replace(/\*\*[^*]+\*\*/g, (m) => kleur.bold(m))
      .replace(/\*[^*]+\*/g, (m) => kleur.italic(m))
      .replace(/`[^`]+`/g, (m) => kleur.bgBlack().white(m))
      .replace(/\[([^\]]+)\]\([^)]+\)/g, (_, t) => kleur.underline().cyan(t));
  }
  if (lang === 'yaml') {
    return line
      .replace(/^(\s*)(\S[\w\-]*):/, (_, indent, k) => `${indent}${kleur.yellow(k)}:`)
      .replace(/:\s*(".*?"|'.*?')/g, (_, v) => `: ${kleur.green(v)}`)
      .replace(/#.*/, (m) => kleur.gray(m));
  }
  return line;
}

/**
 * Estimate the total tokens and cost for a pending user message.
 * Includes: context files + conversation history (last 12 messages) + current input.
 * Returns { tok, cost } where cost is in USD.
 */
function estimatePendingCost(inputText, state) {
  const ctxFiles = [...state.contextPaths].sort();
  let ctxTok = 0;
  for (const relPath of ctxFiles) {
    const content = readPreview(state.cwd, relPath, 6000);
    ctxTok += estimateTokens(content);
  }
  const histTok = state.messages.slice(-12).reduce((sum, m) => sum + estimateTokens(m.content.slice(0, 300)), 0);
  const inputTok = estimateTokens(inputText);
  const total = ctxTok + histTok + inputTok;
  const costObj = estimateCost(total, 0, state.config.model);
  return { tok: total, cost: costObj.totalCost };
}

export function renderHeader(state, width) {
  const workspace = state.cwd.split('/').filter(Boolean).pop() ?? state.cwd;
  const lines = renderCompactBanner(state, width);
  lines.push(truncate(kleur.gray(`Directory ${state.cwd}`), width));
  lines.push(truncate(kleur.gray(`workspace ${workspace} · /mode to switch · /help for commands`), width));
  return lines;
}

function mutedStateLabel(status) {
  return kleur.gray(String(status || 'ready').toLowerCase());
}

export function renderStatusCard(state, width = 58) {
  const lines = [
    kleur.bold('Session'),
    kleur.gray(`• ${state.status}`),
    kleur.gray(`• ${state.busy ? 'busy' : 'idle'}`),
    kleur.gray(`• messages: ${state.messages.length}`),
    kleur.gray(`• backend: ${state.config.baseUrl}`),
    kleur.gray(`• model: ${state.config.model}`),
    kleur.gray(`• mode: ${formatModeName(state.mode)}`),
  ];

  // Connection health line — green when connected, red when unreachable
  if (state.backend?.health === 'ok') {
    lines.push(kleur.green(`• connection: connected · ${state.backend.lastLatencyMs ?? '?'}ms`));
  } else if (state.backend?.health === 'error') {
    lines.push(kleur.red(`• connection: disconnected · ${state.backend.lastError ?? 'unreachable'}`));
  }

  if (state.lastError) lines.push(kleur.red(`• error: ${state.lastError}`));
  if (state.backend?.lastLatencyMs != null && state.backend.health !== 'ok') {
    lines.push(kleur.gray(`• last latency: ${state.backend.lastLatencyMs}ms`));
  }

  // Live streaming stats — show elapsed time + token count + throughput
  if (state.busy && state.streamingStartTime) {
    const elapsed = ((Date.now() - state.streamingStartTime) / 1000).toFixed(1);
    const count = state.streamingTokenCount;
    const tpm = state.streamingTokMin ?? '…';
    lines.push(kleur.green(`• streaming: ${elapsed}s · ${count} tok · ${tpm} tok/min`));
  }

  // Context budget bar — shows token usage as a visual progress bar
  const budget = state.contextBudget ?? 8192;
  const used = state.contextTokens ?? 0;
  const pct = Math.min(1, used / budget);
  const filled = Math.round(pct * 10);
  const empty = 10 - filled;
  const bar = kleur.green('█'.repeat(filled)) + kleur.gray('░'.repeat(empty));
  const pctLabel = `${(pct * 100).toFixed(0)}%`;
  const budgetLabel = used < budget ? kleur.green(`• context: ${bar} ${pctLabel} (${used}/${budget} tok)`) : kleur.red(`• context: ${bar} ${pctLabel} (${used}/${budget} tok — OVER BUDGET)`);
  lines.push(budgetLabel);

  // Last reply summary — shows tokens, duration, throughput, and approximate cost
  if (state.lastOutputTokens > 0) {
    const durSecs = (state.lastReplyDurationMs / 1000).toFixed(1);
    const costStr = state.lastReplyCost < 0.001
      ? '<$0.001'
      : `$${state.lastReplyCost.toFixed(4)}`;
    lines.push(kleur.gray(`• last reply: ${state.lastOutputTokens} tok · ${durSecs}s · ${state.lastReplyTpm} tpm · ${costStr}`));
  }

  return lines.map((line) => truncate(line, width));
}

export function renderSettingsCard(config, width = 58) {
  const lines = [
    kleur.bold('Config'),
    kleur.gray(`• config: ${config.configPath ?? 'workspace default'}`),
    kleur.gray(`• chat path: ${config.chatPath}`),
    kleur.gray(`• models path: ${config.modelsPath}`),
    kleur.gray(`• temperature: ${config.temperature}`),
    kleur.gray(`• max tokens: ${config.maxTokens}`),
    kleur.gray(`• API key: ${config.apiKey ? 'set' : 'unset'}`),
    kleur.gray(`• autosave: ${config.autosave ? 'on' : 'off'}`),
    kleur.gray(`• theme: ${config.theme}`),
  ];

  return lines.map((line) => truncate(line, width));
}

export function renderModelsCard(models, width = 58) {
  if (!models.length) return [kleur.bold('Models'), kleur.gray('No models loaded. Use /models to refresh.')];
  return [kleur.bold('Models'), ...models.map((model) => kleur.gray(`• ${truncate(model.id ?? model.name ?? JSON.stringify(model), width - 2)}`))];
}

export function renderFilesPane(files, selectedFileIndex, contextPaths, width, height) {
  const visible = files.slice(Math.max(0, selectedFileIndex - height + 1), selectedFileIndex + 1);
  const rows = visible.map((entry, index) => {
    const absoluteIndex = Math.max(0, selectedFileIndex - height + 1) + index;
    const prefix = absoluteIndex === selectedFileIndex ? '▶' : ' ';
    const indent = '  '.repeat(Math.min(entry.depth, 6));
    const icon = entry.type === 'dir' ? '▸' : '•';
    const inContext = contextPaths.has(entry.path);
    const contextMark = inContext ? kleur.green('✓ ') : '  ';
    const rel = entry.path;
    const name = rel.split('/').pop() ?? rel;
    const ext = name.includes('.') ? name.split('.').pop().toLowerCase() : '';
    // File detail: append size + mtime when available (from walkWorkspace stat pass)
    let detail = '';
    if (entry.type === 'file' && entry._stats) {
      detail = ` ${kleur.gray(formatFileSize(entry._stats.size) + ' · ' + formatFileMtime(entry._stats.mtimeMs))}`;
    }
    return truncate(`${prefix} ${contextMark}${indent}${icon} ${name}${detail}`, width);
  });
  while (rows.length < height) rows.push('');
  return rows;
}

// ─── Auth prompt screen ───────────────────────────────────────────────────────

/**
 * Render the full-screen API key capture overlay.
 * Shown when state.authPromptActive is true (no API key configured).
 * Renders a centred panel with the reason message and a prompt for the key.
 */
export function renderAuthPromptScreen(state, width, height, themeColors) {
  const { muted = (t) => t, accent = (t) => t, prompt: promptFn = (t) => t } = themeColors;
  const reason = state.authPromptReason || 'Paste your API key to unlock chat.';
  const lines = [];

  // Top: header bar
  lines.push(kleur.bold().white('Orbitron') + kleur.gray('  ·  api key required'));
  lines.push(repeat('─', width));

  // Vertical padding to centre the panel
  const midRow = Math.floor(height / 2);
  for (let i = 0; i < midRow - 6; i++) lines.push('');

  // Panel header
  const panelW = Math.min(width - 8, 64);
  const panelX = Math.floor((width - panelW) / 2);
  const padLeft = ' '.repeat(panelX);

  lines.push(padLeft + kleur.bold().cyan('▸ Unlock chat'));
  lines.push(padLeft + repeat('─', panelW));
  lines.push(padLeft + truncate('Paste the API key required by your backend to Unlock chat.', panelW));
  lines.push(padLeft + '');

  // Input hint
  const inputLine = kleur.cyan('  Paste your key and press Enter  ');
  lines.push(padLeft + kleur.inverse(inputLine));
  lines.push(padLeft + '');
  lines.push(padLeft + kleur.gray('Esc = dismiss  (key prompt stays active until resolved)'));

  // Footer hint
  lines.push(repeat('─', width));
  lines.push(truncate(kleur.gray(`/help  ·  backend: ${state.config.baseUrl}`), width));

  // Fill remaining rows
  while (lines.length < height) lines.push('');

  return lines.join('\n');
}

// ─── Streaming partial renderer ────────────────────────────────────────────────

/**
 * Strip ANSI escape codes from a string.
 */
function stripAnsi(text) {
  // Strip all ANSI CSI+SGR sequences: \x1b[<params><letter>
  return String(text).replace(/\x1b\[[0-9;]*[A-Za-z]/g, '');
}

/**
 * Take the accumulated streaming partial and render it as live markdown
 * inside the conversation pane.  Shows the last N lines that fit in
 * availableHeight, with full kleur markdown styling.
 * availableHeight: max rows to use for the streaming preview.
 * Returns an array of rendered ANSI lines.
 */
function renderStreamingPreview(partial, availableHeight, themeColors) {
  if (!partial || availableHeight <= 0) return [];
  const { assistant = (t) => t, muted = (t) => t, error = (t) => t } = themeColors;

  // Strip ANSI before re-rendering so we get clean markdown tokens
  const clean = stripAnsi(partial);

  // Limit content to avoid processing huge strings mid-stream
  const trimmed = clean.length > 4000 ? clean.slice(-4000) : clean;

  // Use the full renderMarkdownLines for proper markdown + code highlighting
  const rawLines = trimmed.split('\n');
  // Take the last N lines that fit
  const lines = rawLines.slice(Math.max(0, rawLines.length - availableHeight));

  return lines.map((line) => {
    const rendered = renderMarkdownLine(line);
    return truncate(rendered, 120);
  });
}

/**
 * Render a single line of markdown with proper inline formatting.
 * Uses the same patterns as renderMarkdownLines but for one line.
 */
function renderMarkdownLine(raw) {
  const trimmed = raw.trim();

  // Heading
  const headingMatch = trimmed.match(/^(#{1,6})\s+(.*)/);
  if (headingMatch) {
    const level = headingMatch[1].length;
    const text = headingMatch[2];
    const style = level === 1 ? kleur.bold().cyan : kleur.bold;
    return style(text);
  }

  // Fenced code block fence — dim
  if (trimmed === '```' || trimmed === '~~~') {
    return kleur.gray(trimmed);
  }

  // Language label after fence
  const fenceMatch = trimmed.match(/^```(\w*)/);
  if (fenceMatch) {
    return kleur.gray('```' + fenceMatch[1]);
  }

  // Bullet list
  const listMatch = trimmed.match(/^(\s*)([-*+])\s(.+)/);
  if (listMatch) {
    return kleur.gray(listMatch[1] + listMatch[2] + ' ') + renderInlineSpans(listMatch[3]);
  }

  // Blockquote
  if (trimmed.startsWith('> ')) {
    return kleur.gray('▌ ') + renderInlineSpans(trimmed.slice(2));
  }

  // Blank line
  if (!trimmed) return '';

  // Regular line with inline markdown
  return renderInlineSpans(trimmed);
}

/**
 * Apply inline markdown spans to a line of text.
 * Supports: bold, italic, inline code, strikethrough.
 */
function renderInlineSpans(text) {
  const { muted = (t) => t } = {};
  // Collect all inline spans
  const spans = [];
  // Bold+italic ***text*** or ___text___
  {
    const re = /\*\*\*(.+?)\*\*\*/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      spans.push({ start: m.index, end: m.index + m[0].length, text: m[0], style: kleur.bold().italic });
    }
  }
  {
    const re = /___(\w[\s\S]*?)___/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      spans.push({ start: m.index, end: m.index + m[0].length, text: m[0], style: kleur.bold().italic });
    }
  }
  // Bold **text** or __text__
  {
    const re = /\*\*(.+?)\*\*/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      spans.push({ start: m.index, end: m.index + m[0].length, text: m[0], style: kleur.bold });
    }
  }
  {
    const re = /__(.+?)__/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      spans.push({ start: m.index, end: m.index + m[0].length, text: m[0], style: kleur.bold });
    }
  }
  // Italic *text* or _text_
  {
    const re = /(?<!\*)\*([^*\n]+?)\*(?!\*)/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      spans.push({ start: m.index, end: m.index + m[0].length, text: m[0], style: kleur.italic });
    }
  }
  {
    const re = /(?<!_)_\w[\w]*?_/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      spans.push({ start: m.index, end: m.index + m[0].length, text: m[0], style: kleur.italic });
    }
  }
  // Inline code `code`
  {
    const re = /`([^`]+)`/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      spans.push({ start: m.index, end: m.index + m[0].length, text: m[0], style: (t) => kleur.bgBlack().white(t) });
    }
  }
  // Strikethrough ~~text~~
  {
    const re = /~~(.+?)~~/g;
    let m;
    while ((m = re.exec(text)) !== null) {
      spans.push({ start: m.index, end: m.index + m[0].length, text: m[0], style: kleur.strikethrough });
    }
  }

  if (!spans.length) return kleur.white(text);

  // Sort and merge non-overlapping spans
  spans.sort((a, b) => a.start - b.start || a.end - b.end);
  const result = [];
  let pos = 0;
  for (const span of spans) {
    if (span.start < pos) continue;
    if (span.start > pos) result.push({ text: text.slice(pos, span.start), style: kleur.white });
    result.push({ text: span.text, style: span.style });
    pos = span.end;
  }
  if (pos < text.length) result.push({ text: text.slice(pos), style: kleur.white });

  return result.map(({ text: t, style }) => style(t)).join('');
}

/**
 * Render the conversation history as an array of coloured lines.
 * Shows: [time] role › content (with markdown styling).
 * Accepts conversationScroll (0 = most recent page) to page through history.
 */
export function renderChatPane(messages, messageTimestamps, input, width, height, runningCommand, inputCursor, streamingPartial, conversationScroll, typingIndicator, typingDots, streamingStartTime, streamingTokenCount, streamingTokMin, lastResponseDiff, diffExpanded) {
  const rows = [];
  const assistantStyle = (t) => kleur.green(t);
  const systemStyle = (t) => kleur.yellow(t);
  const userStyle = (t) => kleur.cyan(t);

  const ts = messageTimestamps ?? [];
  const pageSize = Math.max(4, height - 5);
  const totalPages = Math.max(1, Math.ceil(messages.length / pageSize));
  // Clamp scroll so the last page is always reachable
  const clampedScroll = Math.min(conversationScroll, Math.max(0, totalPages - 1));
  const startIdx = Math.max(0, messages.length - pageSize * (clampedScroll + 1));
  const endIdx = Math.min(messages.length, startIdx + pageSize);
  const msgSlice = messages.slice(startIdx, endIdx);

  // Page indicator shown in top-right corner of conversation pane
  if (totalPages > 1 && clampedScroll > 0) {
    rows.push(kleur.gray(`▴ page ${clampedScroll + 1}/${totalPages} (older)`));
  }

  for (let i = 0; i < msgSlice.length; i++) {
    const message = msgSlice[i];
    const isLast = i === msgSlice.length - 1 && clampedScroll === 0;
    const origIdx = startIdx + i;
    const msgTs = ts[origIdx] ?? null;
    const timeLabel = msgTs ? formatMsgTime(msgTs) : '';
    const label = message.role === 'assistant' ? assistantStyle('assistant') : message.role === 'system' ? systemStyle('system') : userStyle('you');
    let content = message.content;

    // Append streaming partial to the last assistant message while streaming
    if (isLast && message.role === 'assistant' && streamingPartial) {
      content = streamingPartial;
    }
    const timeStr = timeLabel ? `${timeLabel} ` : '         ';
    const headerLine = `${kleur.gray('[')}${timeStr}${label}${kleur.gray(']›')}`;

    // Live streaming stats inline in the chat pane (shown under the last assistant message)
    const showInlineStats = isLast && message.role === 'assistant' && streamingPartial && streamingStartTime != null;
    const contentLines = renderMarkdownLines(content, width - headerLine.length - 2);
    for (let j = 0; j < contentLines.length; j++) {
      const line = contentLines[j];
      if (j === 0) {
        rows.push(`${headerLine} ${line}`);
      } else {
        rows.push(`${kleur.gray('          ')}  ${line}`);
      }
    }
    // Inline throughput stats beneath the last streaming assistant message
    if (showInlineStats) {
      const elapsed = ((Date.now() - streamingStartTime) / 1000).toFixed(1);
      const count = streamingTokenCount ?? 0;
      const tpm = streamingTokMin ?? '…';
      rows.push(kleur.gray(`           ▸ ${elapsed}s · ${count} tok · ${tpm} tok/min`));
    }
    // Response diff: collapsible section showing model-added content after thinking blocks
    if (isLast && message.role === 'assistant' && lastResponseDiff) {
      const toggleLabel = diffExpanded
        ? kleur.gray('▼ [/result] ' + truncate(lastResponseDiff.slice(0, 60), 40))
        : kleur.gray('▶ [/result] ' + truncate(lastResponseDiff.slice(0, 60), 40));
      rows.push(toggleLabel);
      if (diffExpanded) {
        const diffLines = renderMarkdownLines(lastResponseDiff, width - headerLine.length - 2);
        for (let j = 0; j < diffLines.length; j++) {
          rows.push(`${kleur.gray('           ')}  ${diffLines[j]}`);
        }
      }
    }
    rows.push('');
  }

  // Show animated typing indicator as the last assistant message placeholder when waiting
  if (typingIndicator) {
    const frames = ['   ', '.  ', '.. ', '...'];
    const dots = frames[typingDots % 4];
    const indicator = kleur.gray('          ')+'  '+kleur.italic().dim('typing'+dots);
    rows.push(indicator);
    rows.push('');
  }

  while (rows.length < height) rows.push('');
  return rows.slice(0, height);
}

/**
 * Render a compact context strip shown above the input area.
 * Displays: included files list, system prompt summary, and model/temperature info.
 * Used as the top portion of the input area panel.
 */
export function renderContextStrip(state, width) {
  const ctxFiles = [...state.contextPaths].sort();
  const hasFiles = ctxFiles.length > 0;
  const hasSystem = state.config.systemPrompt?.trim();

  const lines = [];
  const maxWidth = width - 2; // account for leading "> "

  // Context files line
  if (hasFiles) {
    const fileList = ctxFiles.join(', ');
    const budgetLines = ctxFiles.map((p) => {
      const content = readPreview(state.cwd, p, 6000);
      return estimateTokens(content);
    });
    const totalCtxTokens = budgetLines.reduce((s, n) => s + n, 0);
    const ctxLine = `${kleur.green('▸ context:')} ${truncate(fileList, maxWidth - 30)}`;
    lines.push(truncate(ctxLine, maxWidth));
    lines.push(truncate(kleur.gray(`  ${ctxFiles.length} files · ≈${totalCtxTokens} ctx tok`), maxWidth));
  } else {
    lines.push(truncate(kleur.gray('▸ no context files  ·  Tab to include, /include <path>'), maxWidth));
  }

  // System prompt summary line
  if (hasSystem) {
    const summary = truncate(state.config.systemPrompt, maxWidth - 14);
    lines.push(truncate(kleur.gray('▸ ') + truncate(kleur.cyan('sys: ') + summary, maxWidth - 2), maxWidth));
  }

  // Model + temp line
  const modelLine = `▸ model: ${state.config.model}  ·  temp: ${state.config.temperature}  ·  max-tok: ${state.config.maxTokens}`;
  lines.push(truncate(kleur.gray(modelLine), maxWidth));

  return lines;
}

/**
 * Render the current input as a styled prompt line at the bottom of the conversation pane.
 * Shows: orbitron > [text with visible block cursor] [≈N tok · cost | hint]
 * Returns a single formatted string, already truncated to maxWidth.
 */
export function renderInputLine(input, cursorPos, width, themeColors, pendingCost = null) {
  const { muted = (t) => t, accent = (t) => t } = themeColors;
  const prefix = `${kleur.bold().white('›')} `;
  const inputStart = prefix.length;

  // Render input text with a visible block cursor at cursorPos
  let display = '';
  for (let i = 0; i <= input.length; i++) {
    if (i === cursorPos) {
      display += kleur.inverse(input[i] ?? ' ');
    } else {
      display += input[i] ?? '';
    }
  }

  // Live token/cost preview: show estimated cost as user types
  const costPreview = pendingCost && pendingCost.tok > 0
    ? kleur.cyan(`≈${pendingCost.tok} tok · ~$${pendingCost.cost.toFixed(3)}`) + kleur.gray(' · ')
    : '';
  const hint = muted(costPreview + '/ for commands · Tab complete · Ctrl+J run block');
  const availForInput = width - inputStart - hint.length - 2;
  const truncated = truncate(display, Math.max(4, availForInput));

  return truncate(`${prefix}${truncated}  ${hint}`, width);
}

/**
 * Parse inline markdown and return an array of styled kleur segments.
 * Each segment: { text: string, style: fn } where style is a kleur chain or null.
 * Supports: bold, italic, bold+italic, inline code, strikethrough, links (label only).
 * Zero-dependency — uses only kleur primitives.
 */
export function parseInlineMarkdown(text) {
  if (!text) return [{ text: '', style: null }];
  // Apply patterns longest-first so e.g. ***bolditalic*** is consumed before **bold**
  return applyMarkdownSpans(text, [
    { pat: /\*\*\*(.+?)\*\*\*/gs, style: kleur.bold().italic },
    { pat: /\*\*(.+?)\*\*/g, style: kleur.bold },
    { pat: /\*(.+?)\*/g, style: kleur.italic },
    { pat: /~~(.+?)~~/g, style: kleur.strikethrough },
    { pat: /`([^`]+)`/g, style: (t) => kleur.bgBlack().white(t) },
    { pat: /\[([^\]]+)\]\([^)]+\)/g, style: (t) => kleur.underline().cyan(t) },
  ]);
}

function applyMarkdownSpans(text, patterns) {
  // Collect all non-overlapping spans with their positions and styles
  const spans = [];
  for (const { pat, style } of patterns) {
    const re = new RegExp(pat.source, pat.flags);
    let match;
    while ((match = re.exec(text)) !== null) {
      spans.push({ start: match.index, end: match.index + match[0].length, text: match[0], style });
    }
  }
  if (!spans.length) return [{ text, style: null }];
  // Sort by start position, skip overlapping spans (keep first)
  spans.sort((a, b) => a.start - b.start || a.end - b.end);
  const result = [];
  let pos = 0;
  for (const span of spans) {
    if (span.start < pos) continue;
    if (span.start > pos) result.push({ text: text.slice(pos, span.start), style: null });
    result.push({ text: span.text, style: span.style });
    pos = span.end;
  }
  if (pos < text.length) result.push({ text: text.slice(pos), style: null });
  return result;
}

/**
 * Render a markdown string as coloured ANSI output, returning an array of
 * pre-coloured lines (each element is already ANSI-escaped where needed).
 * Handles block-level elements: headings, HR, blockquotes, code fences, lists.
 */
export function renderMarkdownLines(text, maxWidth) {
  if (!text) return [''];
  const lines = [];
  const rawLines = text.split('\n');

  let inCodeBlock = false;
  let codeLang = '';

  for (let i = 0; i < rawLines.length; i++) {
    const raw = rawLines[i];

    // Code fence open/close
    const fenceMatch = raw.match(/^```(\w*)/);
    if (fenceMatch) {
      if (!inCodeBlock) {
        inCodeBlock = true;
        codeLang = fenceMatch[1] || 'text';
        lines.push(kleur.gray('┌─' + (codeLang ? ` ${codeLang} ` : ' code ') + '─┐'));
      } else {
        lines.push(kleur.gray('└─────────────────────────────────────────────┘'));
        inCodeBlock = false;
        codeLang = '';
      }
      continue;
    }

    if (inCodeBlock) {
      lines.push(kleur.gray('  ' + truncate(raw, maxWidth - 2)));
      continue;
    }

    // Heading
    const headingMatch = raw.match(/^(#{1,6})\s+(.*)/);
    if (headingMatch) {
      const level = headingMatch[1].length;
      const content = headingMatch[2];
      if (level === 1) lines.push(kleur.bold().cyan(truncate(content, maxWidth)));
      else if (level === 2) lines.push(kleur.bold().cyan(truncate(content, maxWidth)));
      else lines.push(kleur.cyan().bold(truncate(content, maxWidth)));
      continue;
    }

    // Horizontal rule
    if (/^[-*_]{3,}$/.test(raw.trim())) {
      lines.push(kleur.gray(repeat('─', Math.min(maxWidth, 40))));
      continue;
    }

    // Blockquote
    const bqMatch = raw.match(/^>\s?(.*)/);
    if (bqMatch) {
      lines.push(kleur.gray('▸ ' + truncate(bqMatch[1], maxWidth - 2)));
      continue;
    }

    // Unordered list item
    const listMatch = raw.match(/^(\s*)[-*+]\s+(.*)/);
    if (listMatch) {
      const indent = listMatch[1].length;
      lines.push(' '.repeat(indent) + kleur.gray('• ') + truncate(listMatch[2], maxWidth - indent - 2));
      continue;
    }

    // Indented code (starts with 4+ spaces or a tab)
    if (raw.match(/^(    |\t)/)) {
      lines.push(kleur.gray('  ' + truncate(raw.trim(), maxWidth - 2)));
      continue;
    }

    // Regular text — apply inline markdown spans
    const segments = parseInlineMarkdown(raw);
    const coloured = segments.map(({ text, style }) => style ? style(text) : text).join('');
    lines.push(truncate(coloured, maxWidth));
    // Tables (GFM: | col | col | rows separated by |---|---|
    if (raw.match(/^\|[\s\S]+\|$/)) {
      lines.push(truncate(kleur.yellow(raw), maxWidth));
    }
  }

  return lines;
}

/**
 * Scrollable file preview panel — renders a bordered, scrollable pane of
 * syntax-highlighted file content with line numbers, header, and footer.
 * Shows `state.previewScroll` offset lines, up to `previewHeight` rows.
 */
export function renderPreviewPane(state, width, height) {
  const selected = state.files[state.selectedFileIndex];
  if (!selected || selected.type !== 'file') {
    return [kleur.bold('Preview'), kleur.gray('No file selected.'), kleur.gray('↑↓=navigate  Enter=preview  Esc=close')];
  }

  const abs = state.cwd + '/' + selected.path;
  const ext = selected.path.split('.').pop()?.toLowerCase() ?? '';
  const lang = langFromExt(ext);
  const result = readFilePreviewSync(abs);
  if (!result) {
    return [kleur.bold('Preview'), kleur.red('(cannot read file)'), kleur.gray('↑↓=navigate  Esc=close')];
  }

  const { lines, total } = result;
  // Deduce preview height: header(1) + divider(1) + content(≈) + divider(1) + footer(1)
  // In preview mode the layout is: header+divider + filesHeight + contextBar + div + previewPane
  // so preview gets the remainder after the top portion.
  const filesHeight = Math.min(height - 9, 10);
  const previewHeight = Math.max(8, height - filesHeight - 4);
  const scroll = state.previewScroll ?? 0;
  const maxScroll = Math.max(0, total - previewHeight + 2);
  const clampedScroll = Math.min(scroll, maxScroll);
  const visibleLines = lines.slice(clampedScroll, clampedScroll + previewHeight - 4);

  const leftWidth = Math.max(28, Math.min(48, Math.floor(width * 0.34)));
  const rightWidth = Math.max(30, width - leftWidth - 3);

  const rows = [];
  // Header
  rows.push(kleur.bold(`▸ ${selected.path} `) + kleur.gray(`${total} lines · ${lang} · scroll ${clampedScroll + 1}–${clampedScroll + visibleLines.length} of ${total}`));
  rows.push(repeat('─', width));

  // Content lines with line numbers
  const lineNumWidth = String(total).length;
  for (const [i, line] of visibleLines.entries()) {
    const lineNum = clampedScroll + i + 1;
    const numStr = String(lineNum).padStart(lineNumWidth, ' ');
    const gutter = `${kleur.gray(numStr)} ${kleur.gray('│')} `;
    const coloured = colourLine(line, lang);
    const content = truncate(coloured, width - gutter.length - 1);
    rows.push(gutter + content);
  }

  // Fill remaining content rows with empty space
  while (rows.length < previewHeight - 1) rows.push('');

  // Footer with scroll hint
  rows.push(repeat('─', width));
  const canScrollUp = clampedScroll > 0;
  const canScrollDown = clampedScroll < maxScroll;
  const scrollHint = kleur.gray(
    `↑/↓=scroll${canScrollUp ? ' ▴' : ''}${canScrollDown ? ' ▾' : ''}  Tab=include  Esc=close  Enter=full view`
  );
  rows.push(truncate(scrollHint, width));

  return rows;
}

/**
 * Render a file-search bar for the bottom of the Files column.
 * Shown when state.fileSearchActive is true, accepts a query string,
 * renders it with the matched prefix highlighted, plus navigation hints.
 * Returns an array of lines (for insertion into the file pane array).
 */
export function renderFileSearchBar(state, width) {
  const query = state.fileSearchQuery ?? '';
  const hint = kleur.gray(
    query
      ? `▸ search: \"${kleur.yellow(query)}\"  ↑↓ jump  Enter=open  Esc=cancel`
      : '▸ search…  Esc=cancel',
  );
  return [truncate(hint, width)];
}

// ─── File-search-aware Files pane renderer ────────────────────────────────────

/**
 * Highlight the search query substring in a filename with inverse colouring.
 * Returns the styled ANSI string.
 */
function highlightSearchMatch(filename, query) {
  if (!query) return kleur.green(filename);
  const q = query.toLowerCase();
  const lower = filename.toLowerCase();
  const idx = lower.indexOf(q);
  if (idx < 0) return kleur.green(filename);
  const before = filename.slice(0, idx);
  const match = filename.slice(idx, idx + q.length);
  const after = filename.slice(idx + q.length);
  return kleur.green(before) + kleur.inverse(match) + kleur.green(after);
}

/**
 * Filter files by search query and render as a searchable file list.
 * Shows a search bar row at the top when active, filters to matching files,
 * highlights query matches in filenames, and shows match count.
 */
export function renderFilesPaneSearch(state, width, height) {
  const query = state.fileSearchQuery ?? '';
  const qLower = query.toLowerCase();

  // Filter: only files whose name contains the query
  const allFiles = state.files ?? [];
  const filtered = query
    ? allFiles.filter((f) => f.type === 'file' && f.path.split('/').pop()?.toLowerCase().includes(qLower))
    : allFiles;

  const matchCount = filtered.length;
  const selectedIdx = filtered.findIndex((f, i) => allFiles[state.selectedFileIndex] === f);
  const curIdx = selectedIdx >= 0 ? selectedIdx : 0;

  const rows = [];

  // Top row: search bar
  const queryDisplay = query
    ? kleur.yellow(`\"${query}\"`)
    : kleur.gray('type to filter…');
  const countStr = matchCount > 0
    ? kleur.green(`${matchCount} matches`)
    : kleur.red('no matches');
  rows.push(truncate(`${kleur.cyan('▸ find:')} ${queryDisplay}  ${countStr}  Ctrl+F=close`, width));

  // Divider
  rows.push(kleur.gray('─'.repeat(Math.min(width, 30))));

  // File list (up to height-3 rows, centered around selection)
  const listRows = Math.max(4, height - 3);
  const startIdx = Math.max(0, Math.min(curIdx - Math.floor(listRows / 2), filtered.length - listRows));
  const visible = filtered.slice(startIdx, startIdx + listRows);

  for (let i = 0; i < visible.length; i++) {
    const entry = visible[i];
    const absoluteIdx = startIdx + i;
    const isSelected = absoluteIdx === curIdx;
    const prefix = isSelected ? kleur.inverse('▶') : ' ';
    const indent = '  '.repeat(Math.min(entry.depth, 6));
    const icon = entry.type === 'dir' ? '▸' : '•';
    const inContext = state.contextPaths?.has(entry.path);
    const contextMark = inContext ? kleur.green('✓ ') : '  ';
    const name = entry.path.split('/').pop() ?? entry.path;
    const highlighted = highlightSearchMatch(name, query);
    // File detail: append size + mtime when available
    let detail = '';
    if (entry.type === 'file' && entry._stats) {
      detail = ` ${kleur.gray(formatFileSize(entry._stats.size) + ' · ' + formatFileMtime(entry._stats.mtimeMs))}`;
    }
    rows.push(truncate(`${prefix} ${contextMark}${indent}${icon} ${highlighted}${detail}`, width));
  }

  // Fill remaining rows
  while (rows.length < height) rows.push('');

  return rows;
}

/**
 * Render a live streaming progress bar shown below the footer during active streaming.
 * Visual bar (█░) + elapsed time + token count + tok/min throughput.
 * Returns a single line string, already truncated to maxWidth.
 * Returns empty string when not streaming.
 */
export function renderStreamingStatusBar(state, width) {
  if (!state.busy || !state.streamingStartTime) return '';

  const elapsed = ((Date.now() - state.streamingStartTime) / 1000).toFixed(1);
  const count = state.streamingTokenCount;
  const tpm = state.streamingTokMin ?? '…';

  // Visual progress bar — fills over 10 seconds of streaming
  const totalBars = Math.min(width - 30, 20);
  const elapsedSecs = (Date.now() - state.streamingStartTime) / 1000;
  const fill = Math.min(totalBars, Math.round((elapsedSecs / 10) * totalBars));
  const empty = totalBars - fill;
  const bar = kleur.green('█'.repeat(fill)) + kleur.gray('░'.repeat(empty));

  const label = `${bar}  ${kleur.green(count + ' tok')}  ${kleur.gray(elapsed + 's')}  ${kleur.cyan(tpm + ' tpm')}`;

  return truncate(label, width);
}

/**
 * Render a compact visual budget meter shown in the footer during input.
 * Displays: context file tokens + current input as a progress bar + token count + USD cost.
 * Returns a single formatted string, already truncated to maxWidth.
 */
export function renderBudgetMeter(state, width) {
  const inputText = state.input ?? '';
  const ctxFiles = [...state.contextPaths].sort();
  let ctxTok = 0;
  for (const relPath of ctxFiles) {
    const content = readPreview(state.cwd, relPath, 6000);
    ctxTok += estimateTokens(content);
  }
  const inputTok = estimateTokens(inputText);
  const totalTok = ctxTok + inputTok;

  const budget = state.contextBudget ?? 8192;
  const pct = Math.min(1, totalTok / budget);
  const filled = Math.round(pct * 10);
  const empty = 10 - filled;

  // Colour: green < 60%, yellow 60-85%, red > 85%
  const barColor = pct < 0.6 ? kleur.green : pct < 0.85 ? kleur.yellow : kleur.red;
  const bar = barColor('█'.repeat(filled)) + kleur.gray('░'.repeat(empty));

  const costObj = estimateCost(totalTok, 0, state.config.model);
  const costStr = costObj.totalCost < 0.001
    ? '<$0.001'
    : `$${costObj.totalCost.toFixed(3)}`;

  const ctxLabel = ctxFiles.length > 0
    ? kleur.green(`${ctxFiles.length} ctx`)
    : kleur.gray('no ctx');
  const pctLabel = `${(pct * 100).toFixed(0)}%`;
  const label = `${bar}  ${kleur.gray('budget')} ${pctLabel}  ${kleur.gray('·')}  ${kleur.cyan(`${totalTok.toLocaleString()} tok`)}  ${kleur.gray('·')}  ${kleur.cyan(costStr)}  ${kleur.gray('·')}  ${ctxLabel}`;

  return truncate(label, width);
}

export function renderOverview(state, width, height, themeColors = {}) {
  const {
    prompt = (t) => t,
    assistant = (t) => t,
    user = (t) => t,
    system = (t) => t,
    error = (t) => t,
    muted = (t) => t,
    accent = (t) => t,
    bold = (t) => t,
  } = themeColors;

  if (state.authPromptActive) {
    return renderAuthPromptScreen(state, width, height, themeColors);
  }

  // ── Compact mode: single-column chat pane only ────────────────────────────
  if (state.compactMode) {
    const chatHeight = Math.max(6, height - 4);
    const msgRows = renderChatPane(
      state.messages,
      state.messageTimestamps,
      state.input,
      width,
      chatHeight,
      null,
      state.inputCursor ?? 0,
      state.streamingPartial ?? '',
      state.conversationScroll ?? 0,
      false,
      state.streamingStartTime ?? null,
      state.streamingTokenCount ?? 0,
      state.streamingTokMin ?? null,
      state.lastResponseDiff ?? null,
      state.diffExpanded,
    );
    const inputLine = renderInputLine(
      state.input ?? '',
      state.inputCursor ?? 0,
      width,
      themeColors,
      estimatePendingCost(state.input ?? '', state),
    );
    const lines = [];
    const title = kleur.white().bold('Orbitron') + kleur.gray(` · ${state.config.model} · compact · /c or /compact to restore`);
    lines.push(pad(truncate(title, width), width));
    lines.push(renderModeStrip(state, width));
    lines.push(repeat('─', width));
    for (let i = 0; i < chatHeight; i++) {
      lines.push(pad(msgRows[i] ?? '', width));
    }
    lines.push(repeat('─', width));
    lines.push(inputLine);
    const budget = estimateTokens((state.messages.map(m => m.content).join(' ')));
    const cost = estimateCost(budget, 0, state.config.model);
    lines.push(truncate(kleur.gray(`/compact /c  ·  ${state.busy ? 'streaming…' : 'ready'}  ·  ≈${budget} tok · ~${cost.totalCost.toFixed(4)}¢  ·  ?help`), width));

    // Streaming status bar — appears below the footer during active streaming
    const streamingBar = renderStreamingStatusBar(state, width);
    if (streamingBar) lines.push(truncate(streamingBar, width));

    return lines.join('\n');
  }

  const previewMode = state.previewFile ?? false;
  const leftWidth = Math.max(28, Math.min(48, Math.floor(width * 0.34)));
  const rightWidth = Math.max(30, width - leftWidth - 3);

  if (previewMode) {
    const previewHeight = Math.max(8, height - 9);
    const previewLines = renderPreviewPane(state, width, height);
    const filesHeight = Math.min(height - previewHeight - 3, 10);

    // File list pane (smaller, top-left)
    const filesPane = renderFilesPane(state.files, state.selectedFileIndex, state.contextPaths, leftWidth, filesHeight);
    const contextCount = state.contextPaths.size;
    const contextLabel = contextCount > 0 ? kleur.green(`${contextCount} in context`) : kleur.gray('none in context');

    const top = renderHeader(state, width);
    const lines = [...top, repeat('─', width)];

    // File list row
    for (let i = 0; i < filesHeight; i++) {
      lines.push(pad(filesPane[i] ?? '', leftWidth) + '│' + pad('', rightWidth));
    }

    lines.push(`${repeat('─', leftWidth)}┴${repeat('─', rightWidth)}`);
    lines.push(pad(kleur.gray('↑↓=navigate  Tab=include  Ctrl+F=find'), leftWidth) + '│' + pad(kleur.gray(`Context: ${contextLabel}`), rightWidth));
    lines.push(repeat('─', width));

    // Preview pane lines
    for (let i = 0; i < previewHeight; i++) {
      lines.push(truncate(previewLines[i] ?? '', width));
    }

    return lines.join('\n');
  }

  // Default overview layout
  const headerLines = renderHeader(state, width);
  const contextPane = renderContextStrip(state, width);
  const statusPane = renderStatusCard(state, width);
  const inputText = state.input ?? '';
  const historyText = state.messages.map(m => m.content).join(' ');
  const totalTokens = estimateTokens(inputText) + estimateTokens(historyText);
  const cost = estimateCost(totalTokens, 0, state.config.model);
  const budgetLine = `≈${totalTokens} tok · ~$${cost.totalCost.toFixed(3)}`;
  const footerLines = 4;
  const chatHeight = Math.max(8, height - headerLines.length - contextPane.length - footerLines - 4);
  const chatRows = renderChatPane(
    state.messages,
    state.messageTimestamps,
    state.input,
    width,
    chatHeight,
    state.runningCommand,
    state.inputCursor ?? 0,
    state.streamingPartial ?? '',
    state.conversationScroll ?? 0,
    state.typingIndicator ?? false,
    state.typingDots ?? 0,
    null,
    null,
    state.lastResponseDiff ?? null,
    state.diffExpanded,
  );
  const inputLine = renderInputLine(
    state.input ?? '',
    state.inputCursor ?? 0,
    width,
    themeColors,
    estimatePendingCost(state.input ?? '', state),
  );
  const statusSummary = state.busy
    ? kleur.cyan('working...')
    : state.lastError
      ? kleur.red(`error: ${state.lastError}`)
      : kleur.green('ready');

  const lines = [
    ...headerLines,
    repeat('─', width),
    ...contextPane,
    repeat('─', width),
    ...chatRows,
    repeat('─', width),
    inputLine,
    truncate(kleur.gray(`/${state.mode} mode · ${budgetLine} · /help /models /theme /sessions`) , width),
    truncate(`${statusSummary} ${kleur.gray('·')} ${truncate(statusPane[statusPane.length - 1] ?? '', Math.max(0, width - 12))}`, width),
  ];

  // Streaming status bar — appears below the footer during active streaming
  const streamingBar = renderStreamingStatusBar(state, width);
  if (streamingBar) lines.push(truncate(streamingBar, width));

  return lines.join('\n');
}

/**
 * Render a dismissible keyboard-shortcut reference overlay as a centered modal.
 * Returns an array of lines ready to be shown in a raw-TTY overlay.
 * Callers hide the cursor, draw the modal, and listen for Esc/Enter to dismiss.
 */
export function renderKeyboardHelp(width = 60) {
  const shortcuts = [
    ['Enter', 'Send message (or toggle file preview if input is empty)'],
    ['Tab', 'Tab-complete slash commands; include selected file into context'],
    ['↑ / ↓', 'Browse command history (when input is empty); navigate files/preview'],
    ['← / →', 'Move cursor left/right in input'],
    ['Home / End', 'Jump to start / end of input line'],
    ['Ctrl+A', 'Jump to start of input line'],
    ['Ctrl+E', 'Edit & retry last user message (replace it with your edited version)'],
    ['Ctrl+J', 'Run code block from last AI reply (or send if none)'],
    ['Ctrl+Shift+C', 'Copy last AI reply to clipboard'],
    ['Ctrl+Shift+E', 'Move cursor to end of line'],
    ['Backspace', 'Delete character before cursor'],
    ['Delete', 'Delete character after cursor'],
    ['Ctrl+U', 'Delete from cursor to start of line'],
    ['Ctrl+K', 'Delete from cursor to end of line'],
    ['Ctrl+W', 'Delete last word'],
    ['Ctrl+P', 'Open command palette'],
    ['Ctrl+F', 'Find file by name in the Files pane'],
    ['Ctrl+L', 'Clear screen'],
    ['Ctrl+C', 'Abort streaming / cancel input'],
    ['Esc', 'Close preview / close overlay'],
    ['?', 'Show this keyboard reference'],
    ['PageUp / PageDown', 'Scroll conversation history (when input is empty)'],
  ];

  const col1 = 18;
  const col2 = width - col1 - 2;
  const header = kleur.bold('▸ Keyboard Shortcuts');
  const divider = kleur.gray('─'.repeat(width));

  const rows = [
    header,
    divider,
    ...shortcuts.map(([keys, desc]) => {
      const keyCol = truncate(kleur.cyan().inverse(` ${keys} `), col1);
      const descCol = truncate(kleur.gray(desc), col2);
      return keyCol + ' ' + descCol;
    }),
    divider,
    kleur.gray('Press Esc or Enter to dismiss'),
  ];

  return rows;
}
