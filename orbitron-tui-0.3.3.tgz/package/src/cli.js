#!/usr/bin/env node
import prompts from 'prompts';
import ora from 'ora';
import kleur from 'kleur';
import { Command } from 'commander';
import fs from 'node:fs';
import path from 'node:path';
import { BackendClient } from './backend-client.js';
import { createState } from './state.js';
import { DEFAULT_CONFIG, parseConfigValue, saveConfig } from './config.js';
import { banner, renderHelp, renderModels, renderSettings, renderStatus, renderTranscript, getCompletions, promptCommandPalette, SLASH_COMMANDS } from './ui.js';
import { walkWorkspace } from './files.js';
import { MarkdownStream } from './markdown.js';
import { renderScreen } from './render.js';
import { getTheme } from './themes.js';

// ─── File watcher for live workspace updates ─────────────────────────────────

let fileWatcher = null;
let fileWatcherDebounce = null;

/**
 * Start watching the workspace directory for file changes.
 * Debounces rapid events and calls `redraw()` to refresh the file pane.
 */
function startFileWatcher(cwd, redraw) {
  if (fileWatcher) {
    fileWatcher.close();
    fileWatcher = null;
  }
  if (fileWatcherDebounce) {
    clearTimeout(fileWatcherDebounce);
    fileWatcherDebounce = null;
  }

  try {
    fileWatcher = fs.watch(cwd, { recursive: true }, (eventType, filename) => {
      // Ignore noisy dirs and temp files
      if (!filename) return;
      const skip = ['node_modules', '.git', '.cache', 'sessions', 'Trash'];
      if (skip.some(d => filename.includes(d))) return;

      if (fileWatcherDebounce) clearTimeout(fileWatcherDebounce);
      fileWatcherDebounce = setTimeout(() => {
        fileWatcherDebounce = null;
        redraw();
      }, 800); // debounce ~800ms to coalesce rapid changes
    });
  } catch {
    // Filesystem watch not supported — silently skip
  }
}

function stopFileWatcher() {
  if (fileWatcher) {
    try { fileWatcher.close(); } catch { /* ignore */ }
    fileWatcher = null;
  }
  if (fileWatcherDebounce) {
    clearTimeout(fileWatcherDebounce);
    fileWatcherDebounce = null;
  }
}

const program = new Command();
program
  .name('orbitron')
  .description('A polished terminal chat prototype with neutral workflow UX')
  .option('-m, --message <text>', 'send a one-off message and print the response')
  .option('--model <name>', 'override model for this run')
  .option('--base-url <url>', 'override backend base URL')
  .option('--api-key <key>', 'override API key for this run')
  .option('--temperature <number>', 'override temperature for this run')
  .option('--max-tokens <number>', 'override max tokens for this run')
  .option('--retries <number>', 'override retries for this run')
  .parse(process.argv);

const opts = program.opts();
const state = createState();
state.files = walkWorkspace(state.cwd);

state.config = {
  ...state.config,
  baseUrl: opts.baseUrl ? parseConfigValue('baseUrl', opts.baseUrl) : state.config.baseUrl ?? DEFAULT_CONFIG.baseUrl,
  model: opts.model ? parseConfigValue('model', opts.model) : state.config.model ?? DEFAULT_CONFIG.model,
  apiKey: opts.apiKey ? parseConfigValue('apiKey', opts.apiKey) : state.config.apiKey ?? '',
  temperature: opts.temperature !== undefined ? parseConfigValue('temperature', opts.temperature) : state.config.temperature,
  maxTokens: opts.maxTokens !== undefined ? parseConfigValue('maxTokens', opts.maxTokens) : state.config.maxTokens,
  retries: opts.retries !== undefined ? parseConfigValue('retries', opts.retries) : state.config.retries ?? DEFAULT_CONFIG.retries,
};

const client = new BackendClient(state.config);

// Command history
const history = [];
let historyIndex = -1;

// Readline-style input with Tab completion and multi-line support
function createInteractiveInput(onSubmit) {
  let buffer = '';
  let cursorPos = 0;
  let completionIndex = 0;
  let currentCompletions = [];

  process.stdin.setRawMode?.(true);
  process.stdin.resume?.();
  process.stdin.setEncoding?.('utf8');

  const prompt = kleur.cyan('orbitron');
  process.stdout.write('\n' + prompt + ' ');

  function redrawInput() {
    process.stdout.write('\r' + ' '.repeat(80) + '\r' + prompt + ' ' + buffer + '\x1b[' + (buffer.length - cursorPos + prompt.length + 2) + 'D');
  }

  function printCompletions() {
    if (currentCompletions.length === 0) return;
    process.stdout.write('\n');
    for (const c of currentCompletions) {
      process.stdout.write(kleur.gray('  ' + c) + '\n');
    }
    process.stdout.write('\r' + prompt + ' ' + buffer);
  }

  const handler = (key) => {
    if (key === '\t') {
      if (currentCompletions.length === 0) {
        currentCompletions = getCompletions(buffer, state);
        completionIndex = 0;
      }
      if (currentCompletions.length > 0) {
        buffer = currentCompletions[completionIndex % currentCompletions.length];
        cursorPos = buffer.length;
        completionIndex++;
        redrawInput();
      }
      return;
    }
    if (key === '\x10') { // Ctrl+P — command palette
      process.stdin.pause?.();
      (async () => {
        const chosen = await promptCommandPalette(SLASH_COMMANDS);
        process.stdin.resume?.();
        if (chosen) {
          buffer = chosen;
          cursorPos = buffer.length;
          currentCompletions = [];
          completionIndex = 0;
          redrawInput();
          onSubmit(chosen);
          process.stdout.write(prompt + ' ');
        } else {
          redrawInput();
        }
      })();
      return;
    }
    if (key === '[' || key === '\x1b') {
      // Arrow key prefix - read more
      return;
    }
    if (key === '\x1b[A') { // Up
      if (history.length > 0) {
        if (historyIndex === -1) historyIndex = history.length - 1;
        else if (historyIndex > 0) historyIndex--;
        buffer = history[historyIndex] ?? '';
        cursorPos = buffer.length;
        redrawInput();
      }
      return;
    }
    if (key === '\x1b[B') { // Down
      if (historyIndex !== -1) {
        historyIndex++;
        if (historyIndex >= history.length) {
          historyIndex = -1;
          buffer = '';
        } else {
          buffer = history[historyIndex] ?? '';
        }
        cursorPos = buffer.length;
        redrawInput();
      }
      return;
    }
    if (key === '\x0c') { // Ctrl+L - clear screen
      console.clear();
      printIntro();
      redrawInput();
      return;
    }
    if (key === '\x03') { // Ctrl+C
      process.stdout.write('\n' + kleur.yellow('^C\n'));
      buffer = '';
      cursorPos = 0;
      currentCompletions = [];
      process.stdout.write(prompt + ' ');
      return;
    }
    if (key === '\r' || key === '\n') { // Enter
      process.stdout.write('\n');
      const line = buffer;
      currentCompletions = [];
      completionIndex = 0;
      if (line.trim()) {
        history.push(line);
        if (history.length > 100) history.shift();
      }
      historyIndex = -1;
      buffer = '';
      cursorPos = 0;
      onSubmit(line);
      process.stdout.write(prompt + ' ');
      return;
    }
    if (key === '\x7f') { // Backspace
      if (cursorPos > 0) {
        buffer = buffer.slice(0, cursorPos - 1) + buffer.slice(cursorPos);
        cursorPos--;
        redrawInput();
      }
      return;
    }
    if (key === '\x1b[3~') { // Delete
      if (cursorPos < buffer.length) {
        buffer = buffer.slice(0, cursorPos) + buffer.slice(cursorPos + 1);
        redrawInput();
      }
      return;
    }
    if (key === '\x1b[D') { // Left arrow
      if (cursorPos > 0) {
        cursorPos--;
        redrawInput();
      }
      return;
    }
    if (key === '\x1b[C') { // Right arrow
      if (cursorPos < buffer.length) {
        cursorPos++;
        redrawInput();
      }
      return;
    }
    if (key >= ' ' && key.length === 1) {
      buffer = buffer.slice(0, cursorPos) + key + buffer.slice(cursorPos);
      cursorPos++;
      redrawInput();
    }
  };

  return {
    handler,
    cleanup() {
      process.stdin.setRawMode?.(false);
    },
  };
}

// Simple line-by-line with Tab completion (fallback for non-TTY)
async function readInputWithCompletion(state) {
  return new Promise((resolve) => {
    let buffer = '';
    const prompt = kleur.cyan('orbitron');
    process.stdout.write('\n' + prompt + ' ');

    const onData = (chunk) => {
      const data = chunk.toString();
      for (const char of data) {
        if (char === '\t') {
          const completions = getCompletions(buffer, state);
          if (completions.length > 0) {
            buffer = completions[0];
            process.stdout.write('\r' + prompt + ' ' + buffer + '\x1b[K');
          }
        } else if (char === '\r' || char === '\n') {
          process.stdout.write('\n');
          process.stdin.removeListener('data', onData);
          resolve(buffer);
          break;
        } else if (char === '\x03') { // Ctrl+C
          process.stdout.write('\n' + kleur.yellow('^C\n' + prompt + ' '));
          buffer = '';
        } else if (char >= ' ') {
          buffer += char;
          process.stdout.write(char);
        }
      }
    };

    process.stdin.on('data', onData);
  });
}

// Multi-line input: accumulates lines until blank line, then submits
async function readMultilineInput(state) {
  const lines = [];
  const prompt = kleur.cyan('orbitron');
  let firstLine = true;

  while (true) {
    const linePrompt = firstLine ? kleur.cyan('orbitron') : kleur.gray('...');
    const { value } = await prompts(
      {
        type: 'text',
        name: 'value',
        message: linePrompt,
      },
      { onCancel: () => ({ value: null }) },
    );

    if (value === null) {
      return null; // Ctrl+C
    }

    if (!value.trim()) {
      // Blank line ends input
      break;
    }

    if (firstLine && value.startsWith('/')) {
      // Single-line command - execute immediately
      return value;
    }

    lines.push(value);
    firstLine = false;
  }

  return lines.join('\n');
}

function printBlock(title, content) {
  console.log('\n' + kleur.bold(title));
  console.log(content);
}

function printIntro() {
  console.clear();
  console.log(banner());
  console.log(kleur.gray(`Config file: ${state.config.configPath ?? 'workspace default'}`));
  console.log('');
}

function getViewport() {
  return {
    width: process.stdout.columns || 100,
    height: process.stdout.rows || 32,
  };
}

function redrawScreen() {
  const { width, height } = getViewport();
  console.clear();
  console.log(renderScreen(state, width, Math.max(20, height - 1), getTheme(state.config.theme)));
}

function refreshClient() {
  client.updateConfig(state.config);
}

async function chooseSetting() {
  const response = await prompts(
    {
      type: 'select',
      name: 'field',
      message: 'Which setting do you want to edit?',
      choices: [
        { title: 'Base URL', value: 'baseUrl' },
        { title: 'Chat path', value: 'chatPath' },
        { title: 'Models path', value: 'modelsPath' },
        { title: 'Model', value: 'model' },
        { title: 'Temperature', value: 'temperature' },
        { title: 'Max tokens', value: 'maxTokens' },
        { title: 'Retries', value: 'retries' },
        { title: 'API key', value: 'apiKey' },
        { title: 'System prompt', value: 'systemPrompt' },
        { title: 'Autosave', value: 'autosave' },
        { title: 'Theme', value: 'theme' },
      ],
    },
    { onCancel: () => ({ field: null }) },
  );

  if (!response.field) return;

  const current = state.config[response.field];

  // Theme uses a select picker
  if (response.field === 'theme') {
    const { value: newTheme } = await prompts(
      {
        type: 'select',
        name: 'value',
        message: 'Select a theme',
        choices: [
          { title: 'Cyan — classic cyan-on-dark palette', value: 'default' },
          { title: 'Forest — muted greens on dark', value: 'forest' },
          { title: 'Solarized — Solarized dark palette', value: 'solarized' },
          { title: 'Mono — white on black, minimal', value: 'mono' },
        ],
        initial: [DEFAULT_CONFIG.theme, 'default', 'forest', 'solarized', 'mono'].indexOf(state.config.theme),
      },
      { onCancel: () => ({ value: undefined }) },
    );
    if (newTheme === undefined) return;
    state.config.theme = newTheme;
    refreshClient();
    console.log(kleur.green(`Theme set to ${newTheme}.`));
    return;
  }

  const editor = await prompts(
    {
      type: response.field === 'autosave' ? 'toggle' : 'text',
      name: 'value',
      message: `New value for ${response.field}`,
      initial: String(current),
      active: 'on',
      inactive: 'off',
    },
    { onCancel: () => ({ value: undefined }) },
  );

  if (editor.value === undefined) return;

  state.config[response.field] = parseConfigValue(response.field, editor.value);
  refreshClient();
  console.log(kleur.green(`Updated ${response.field}.`));
}

async function promptApiKey(state) {
  process.stdout.write('\n');
  process.stdout.write(kleur.bold().cyan('▸ API Key Required') + '\n');
  process.stdout.write(kleur.gray('─'.repeat(60)) + '\n');
  process.stdout.write(kleur.gray('Paste your API key below. It will be saved to ') + state.config.configPath + kleur.gray('.\n'));
  process.stdout.write(kleur.gray('Press Esc to skip and use the CLI without a stored key.\n'));
  process.stdout.write(kleur.gray('─'.repeat(60)) + '\n\n');

  let buffer = '';
  process.stdout.write(kleur.cyan('api-key') + kleur.gray(' › '));
  process.stdout.write('\x1b[?25l'); // hide cursor

  return new Promise((resolve) => {
    let escapeBuffer = '';
    let escapeTimer = null;
    const handler = (chunk) => {
      const str = chunk.toString('utf8');

      if (str === '\u0003') {
        // Ctrl+C — skip
        process.stdout.write('\x1b[?25h');
        process.stdout.write('\n' + kleur.yellow('Skipped.\n'));
        process.off('data', handler);
        resolve(null);
        return;
      }
      if (str === '\x1b') {
        escapeBuffer = '\x1b';
        if (escapeTimer) clearTimeout(escapeTimer);
        escapeTimer = setTimeout(() => {
          process.stdout.write('\x1b[?25h');
          process.stdout.write('\n' + kleur.yellow('Skipped.\n'));
          process.off('data', handler);
          resolve(null);
        }, 30);
        return;
      }
      if (escapeBuffer === '\x1b') {
        escapeBuffer = '';
        if (escapeTimer) {
          clearTimeout(escapeTimer);
          escapeTimer = null;
        }
        // Escape — skip
        process.stdout.write('\x1b[?25h');
        process.stdout.write('\n' + kleur.yellow('Skipped.\n'));
        process.off('data', handler);
        resolve(null);
        return;
      }
      if (str === '\r' || str === '\n') {
        if (escapeTimer) {
          clearTimeout(escapeTimer);
          escapeTimer = null;
        }
        process.stdout.write('\x1b[?25h');
        process.stdout.write('\n');
        process.off('data', handler);
        const trimmed = buffer.trim();
        resolve(trimmed || null);
        return;
      }
      if (str === '\x7f') {
        // Backspace
        if (buffer.length > 0) {
          buffer = buffer.slice(0, -1);
          process.stdout.write('\b \b');
        }
        return;
      }
      if (str.length === 1 && str >= ' ') {
        buffer += str;
        process.stdout.write('*');
      }
    };

    process.stdin.on('data', handler);
  });
}

async function sendMessage(text) {
  state.messages.push({ role: 'user', content: text });
  state.status = 'Streaming response';
  state.busy = true;
  refreshClient();

  const controller = new AbortController();
  const replyTokens = [];

  process.stdout.write(kleur.green('\nAssistant: '));

  let cursorChar = '█';
  let cursorVisible = true;
  let cursorInterval;

  const showCursor = () => {
    process.stdout.write(cursorVisible ? kleur.green(cursorChar) : ' ');
    cursorVisible = !cursorVisible;
  };

  const started = Date.now();
  let tokenCount = 0;
  let lastUpdate = started;
  // Live streaming stats — updated on every token for the overview screen bar
  state.streamingStartTime = started;
  state.streamingTokenCount = 0;
  state.streamingTokMin = null;
  state.streamingPartial = '';

  const updateThroughput = () => {
    const elapsed = (Date.now() - started) / 1000;
    const mins = elapsed / 60;
    const tpm = mins > 0 ? Math.round(tokenCount / mins) : tokenCount;
    state.streamingTokMin = tpm;
    const line = `\b\b  \b\b${kleur.green(tokenCount + ' tok')} ${kleur.gray(`· ${elapsed.toFixed(1)}s · ${tpm} tok/min`)}`;
    process.stdout.write(line + '\x1b[K');
  };

  const md = new MarkdownStream((text) => {
    process.stdout.write(text);
    state.streamingPartial += text;
  });

  // Ctrl+C abort — stop streaming gracefully, keep user message
  const abortHandler = () => {
    if (cursorInterval) clearInterval(cursorInterval);
    controller.abort();
    const partial = replyTokens.join('');
    if (partial) state.messages.push({ role: 'assistant', content: partial + ' *(aborted)*' });
    state.status = 'Aborted';
    state.busy = false;
    console.log(kleur.yellow('\n[aborted]'));
  };
  process.on('SIGINT', abortHandler, { once: true });

  try {
    for await (const token of client.streamChat(state.messages, {
      model: state.config.model,
      temperature: state.config.temperature,
      maxTokens: state.config.maxTokens,
      retries: state.config.retries,
    }, controller.signal)) {
      if (cursorInterval) clearInterval(cursorInterval);
      process.stdout.write('\b\b');
      md.accept(token);
      replyTokens.push(token);
      tokenCount++;
      state.streamingTokenCount = tokenCount;
      const now = Date.now();
      if (now - lastUpdate > 600) {
        updateThroughput();
        lastUpdate = now;
      }
      cursorInterval = setInterval(showCursor, 400);
    }

    if (cursorInterval) clearInterval(cursorInterval);
    process.stdout.write('\b\b');
    md.flush();
    const reply = replyTokens.join('');
    const elapsed = ((Date.now() - started) / 1000).toFixed(1);
    const speed = replyTokens.length ? Math.round((replyTokens.length / (Date.now() - started)) * 60000) : 0;
    state.messages.push({ role: 'assistant', content: reply });
    state.backend.lastLatencyMs = Math.round(Date.now() - started);
    state.status = 'Reply received';
    state.lastError = '';
    // Store last reply stats for the Status card
    state.lastOutputTokens = replyTokens.length;
    state.lastReplyDurationMs = Date.now() - started;
    state.lastReplyTpm = speed;
    // Estimate cost using context files + recent history
    const { estimateCost: ec, estimateTokens: et } = await import('./render.js');
    const { readPreview } = await import('./files.js');
    try {
      const ctxFiles = [...state.contextPaths].sort();
      let ctxTok = 0;
      for (const relPath of ctxFiles) {
        ctxTok += et(readPreview(state.cwd, relPath, 6000));
      }
      const histTok = state.messages.slice(-12).reduce((sum, m) => sum + et(m.content.slice(0, 300)), 0);
      const replyCost = ec(ctxTok + histTok, replyTokens.length, state.config.model);
      state.lastReplyCost = replyCost.totalCost;
    } catch { state.lastReplyCost = 0; }
    console.log('\n' + kleur.green('\u2713 ' + replyTokens.length + ' tokens in ' + elapsed + 's') + kleur.gray(' (~' + speed + ' tok/min)'));
  } catch (error) {
    if (cursorInterval) clearInterval(cursorInterval);
    const message = error instanceof Error ? error.message : String(error);
    state.lastError = message;
    state.status = 'Request failed';
    console.log('\b\b\n' + kleur.red('\u2717 ' + message));
  } finally {
    process.off('SIGINT', abortHandler);
    state.busy = false;
    // Clear streaming state so the overview bar disappears
    state.streamingStartTime = null;
    state.streamingTokenCount = 0;
    state.streamingTokMin = null;
    state.streamingPartial = '';
  }
}

async function refreshModels() {
  state.status = 'Fetching models';
  state.busy = true;
  const spinner = ora('Discovering models at backend…').start();
  refreshClient();
  try {
    const models = await client.listModels();
    spinner.succeed(`Discovered ${models.length} models from ${state.config.baseUrl}`);
    state.modelList = models;
    state.status = `Loaded ${models.length} models`;
    state.lastError = '';
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    spinner.fail(`Model discovery failed: ${message.slice(0, 80)}`);
    state.lastError = message;
    state.status = 'Model fetch failed';
  } finally {
    state.busy = false;
  }
}

async function handleCommand(input) {
  if (input === '/quit' || input === '/exit') return 'quit';
  if (input === '/help') {
    printBlock('Help', renderHelp());
    return null;
  }
  if (input === '/status') {
    printBlock('Status', renderStatus(state));
    return null;
  }
  if (input === '/settings') {
    await chooseSetting();
    printBlock('Settings', renderSettings(state.config));
    return null;
  }
  if (input === '/models') {
    await refreshModels();
    return null;
  }
  if (input === '/clear') {
    state.messages = [{ role: 'assistant', content: 'Transcript cleared. Ready for the next prompt.' }];
    printBlock('Transcript', renderTranscript(state.messages));
    return null;
  }
  if (input.startsWith('/set ')) {
    const [, field, ...rest] = input.split(' ');
    const value = rest.join(' ');
    if (!field || !value) {
      console.log(kleur.yellow('Usage: /set <field> <value>'));
      return null;
    }
    if (!(field in state.config)) {
      console.log(kleur.yellow(`Unknown field: ${field}`));
      return null;
    }
    state.config[field] = parseConfigValue(field, value);
    refreshClient();
    console.log(kleur.green(`Updated ${field}.`));
    return null;
  }
  if (input.startsWith('/model ')) {
    const model = input.slice(7).trim();
    if (!model) {
      console.log(kleur.yellow('Usage: /model <name>'));
      return null;
    }
    state.config.model = parseConfigValue('model', model);
    refreshClient();
    console.log(kleur.green(`Model set to: ${state.config.model}`));
    return null;
  }
  if (input.startsWith('/backend ')) {
    const url = input.slice(9).trim();
    if (!url) {
      console.log(kleur.yellow('Usage: /backend <url>'));
      return null;
    }
    state.config.baseUrl = parseConfigValue('baseUrl', url);
    refreshClient();
    console.log(kleur.green(`Backend URL set to: ${state.config.baseUrl}`));
    return null;
  }
  return null;
}

async function interactiveLoop() {
  // If no API key, prompt for it before starting
  if (!state.config.apiKey) {
    const key = await promptApiKey(state);
    if (key) {
      state.config.apiKey = key;
      if (state.config.autosave) saveConfig(state.config);
      console.log(kleur.green('API key saved.'));
    }
  }

  redrawScreen();
  startFileWatcher(state.cwd, redrawScreen);
  await refreshModels();

  while (true) {
    redrawScreen();
    const input = await readMultilineInput(state);

    if (input === null) continue; // Ctrl+C during input
    if (!input.trim()) continue;

    // Handle commands immediately (single-line commands already stripped of multi-line)
    const cmdResult = await handleCommand(input);
    if (cmdResult === 'quit') break;
    if (cmdResult === null && input.startsWith('/')) continue;

    await sendMessage(input);
    redrawScreen();
  }
}

async function oneShot() {
  printIntro();
  if (!opts.message) {
    console.log(kleur.yellow('No message provided.'));
    return;
  }
  await sendMessage(opts.message);
}

async function main() {
  if (opts.message) {
    await oneShot();
    return;
  }

  await interactiveLoop();
  stopFileWatcher();
  if (state.config.autosave) saveConfig(state.config);
  console.log(kleur.gray('Goodbye.'));
}

main().catch((error) => {
  console.error(kleur.red(error instanceof Error ? error.stack ?? error.message : String(error)));
  stopFileWatcher();
  process.exitCode = 1;
});
