import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { DEFAULT_CONFIG, loadConfig, mergeConfig, parseConfigValue, saveConfig } from '../src/config.js';
import { createState } from '../src/state.js';
import { renderScreen } from '../src/render.js';
import { walkWorkspace } from '../src/files.js';
import { getTheme } from '../src/themes.js';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'orbitron-smoke-'));
const configPath = path.join(tmp, 'orbitron.config.json');
process.env.ORBITRON_CONFIG_PATH = configPath;

const config = loadConfig({ cwd: tmp });
assert.equal(config.baseUrl, DEFAULT_CONFIG.baseUrl);
assert.equal(config.chatPath, '/api/chat');
assert.equal(parseConfigValue('autosave', 'true'), true);
assert.equal(parseConfigValue('temperature', '0.7'), 0.7);
assert.equal(parseConfigValue('baseUrl', 'https://example.com/'), 'https://example.com');
assert.equal(parseConfigValue('modelsPath', 'models'), '/models');

const savedPath = saveConfig({ ...config, model: 'test-model', configPath });
assert.equal(savedPath, configPath);
assert.ok(fs.existsSync(configPath));

const state = createState({ cwd: tmp, config: { configPath, baseUrl: config.baseUrl, apiKey: 'test-key' } });
state.files = walkWorkspace(tmp);
const theme = getTheme('default');
assert.equal(typeof theme.prompt, 'function');
assert.equal(typeof theme.assistant, 'function');
const screen = renderScreen(state, 120, 40, theme);
assert.match(screen, /Codebuff/i);
assert.match(screen, /Generate code from the terminal!/i);
assert.match(screen, /Directory/);
assert.match(screen, /Mode:/);
assert.match(screen, /\/mode/);
assert.match(screen, /\/help \/models \/theme \/sessions/);

const lockedState = createState({ cwd: tmp, config: { configPath, baseUrl: config.baseUrl, apiKey: '' } });
const lockedScreen = renderScreen(lockedState, 120, 30, theme);
assert.match(lockedScreen, /Unlock chat/);
assert.match(lockedScreen, /api key/);

const merged = mergeConfig({ baseUrl: 'https://orbitron--pastelsjuice8t.replit.app///', modelsPath: 'api/models' });
assert.equal(merged.baseUrl, 'https://orbitron--pastelsjuice8t.replit.app');
assert.equal(merged.modelsPath, '/api/models');

console.log('smoke ok');
