# Orbitron TUI

A polished terminal chat prototype with a Codebuff-style full-screen layout while keeping Orbitron's own backend flow. Connects to any OpenAI-compatible backend — default endpoint is `https://orbitron--pastelsjuice8t.replit.app`.

## Install

```bash
npm install
```

## Run

```bash
npx orbitron
# or from this directory:
node bin/orbitron
```

First-run will fetch the available models list from the configured backend.

The default launch surface now uses:

- a large Orbitron hero header
- full-width conversation flow
- bottom command/status strip
- `/mode` switching with the current mode visible in the header

Startup now waits for model discovery before entering the prompt, which avoids the previous terminal stall right after the model list loaded.

## Configuration

Config is saved to `orbitron.config.json` in the current working directory, or use `ORBITRON_CONFIG_PATH` to set a custom location.

| Field | Default |
|---|---|
| `baseUrl` | `https://orbitron--pastelsjuice8t.replit.app` |
| `chatPath` | `/api/chat` |
| `modelsPath` | `/api/models` |
| `model` | `gpt-4.1-mini` |
| `temperature` | `0.2` |
| `maxTokens` | `2048` |
| `retries` | `3` |
| `apiKey` | _(empty)_ |

Environment variables (`ORBITRON_*`) take precedence over config file values.

## Verification

```bash
npm test
```
